# -*- coding: utf-8 -*-
"""
make_figures_svg.py — vector (SVG and PDF) versions of Figures 1-4 from the CSV outputs of run_all.

Usage:  python tools/make_figures_svg.py --results results --out figures
Writes: figure1_platform_gamma, figure2_synthetic_gamma, figure3_gamma_anchors, figure4_benchmarks_gamma (.svg and .pdf)
"""
import argparse
import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

plt.rcParams.update({"font.size": 9, "axes.titlesize": 9.5, "axes.labelsize": 9, "legend.fontsize": 7,
                     "xtick.labelsize": 8, "ytick.labelsize": 8, "svg.fonttype": "path",
                     "axes.spines.top": False, "axes.spines.right": False})
C_POST, C_PRE, C_COAT, C_KR = "#1f77b4", "#d62728", "#2ca02c", "#ff7f0e"


def save(fig, out, name):
    fig.tight_layout()
    for ext in ("svg", "pdf"):
        fig.savefig(out / f"{name}.{ext}", bbox_inches="tight")
    plt.close(fig)
    print("written:", out / f"{name}.svg")


def anchors(r):
    coat = pd.read_csv(r / "coat_t4" / "value_by_rule.csv")
    coat = coat[np.isclose(coat.q, 0.10)].gamma_cover_point
    kr = pd.concat([pd.read_csv(r / d / "value.csv") for d in ["kuairand_click", "kuairand_longview"]
                    if (r / d / "value.csv").exists()])
    kr = kr[(kr.mu == "corr_gbdt") & np.isclose(kr.q, 0.05)].gamma_cover
    return (coat.min(), coat.max()), (kr.min(), kr.max())


def fig1(r, out, coat_rng, kr_rng):
    cv = pd.read_csv(r / "platform_step4" / "gamma_curves_primary.csv")
    st = pd.read_csv(r / "platform_step4" / "gamma_star_by_seed.csv")
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9))
    for ax, mu, lab in zip(axes, ["gbdt", "logistic"], ["gradient-boosted", "logistic"]):
        a = cv[(cv.mu == mu) & (cv.rule == "corr_gbdt") & (cv.gamma < 1e8)].sort_values("gamma")
        b = cv[(cv.mu == mu) & (cv.rule == "raw_S") & (cv.gamma < 1e8)].sort_values("gamma")
        lo, hi = a.V_lo.values - b.V_hi.values, a.V_hi.values - b.V_lo.values
        ax.axvspan(*coat_rng, color=C_COAT, alpha=0.15, lw=0, label="Coat empirical Γ (self-selection)")
        ax.axvspan(*kr_rng, color=C_KR, alpha=0.15, lw=0, label="KuaiRand empirical Γ (exposure)")
        ax.fill_between(a.gamma, lo, hi, color=C_POST, alpha=0.35, lw=0, label="VoV interval")
        ax.plot(a.gamma, lo, color=C_POST, lw=0.8)
        ax.plot(a.gamma, hi, color=C_POST, lw=0.8)
        ax.axhline(0, color="grey", lw=0.7)
        g = st[(st.seed == st.seed.iloc[0]) & (st.B == 500) & (st.mu == mu) & (st.post == "corr_gbdt")].gamma_star.iloc[0]
        if np.isfinite(g):
            ax.axvline(g, color=C_PRE, ls=":", lw=1.2, label=f"Γ* = {g:.2f}")
        ax.set_xscale("log")
        ax.set_xlabel("Γ")
        ax.set_ylabel("VoV (top-500)")
        ax.set_title(f"Value model: {lab}")
        ax.legend(loc="lower left", frameon=False)
    save(fig, out, "figure1_platform_gamma")


def fig2(r, out):
    d = pd.read_csv(r / "synthetic" / "synthetic_results.csv")
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9), sharey=True)
    for ax, t, title in [(axes[0], 0.0, "Additive outcome (t = 0)"), (axes[1], 1.5, "Interaction in outcome (t = 1.5)")]:
        s = d[d.t == t]
        for nm, mk, col, lab, sh in [("pre", "s", C_PRE, r"platform-like signal ($\pi_{\mathrm{pre}}$)", 0.97),
                                     ("gbdt", "o", C_POST, r"fitted GBDT rule ($\pi_{\mathrm{post}}$)", 1.03)]:
            g = s.groupby("kappa")[f"{nm}_gamma_cover"]
            x = np.exp(g.median().index.values) * sh
            med, q1, q9 = g.median().values, g.quantile(.1).values, g.quantile(.9).values
            ax.errorbar(x, med, yerr=[med - q1, q9 - med], fmt=mk, color=col, ms=4, capsize=2.5, lw=1, label=lab)
        xx = np.linspace(1, 4.6, 10)
        ax.plot(xx, xx, "k--", lw=0.8, label="empirical Γ = exp(κ)")
        ax.set_xlabel("true selection strength exp(κ)")
        ax.set_title(title)
        ax.legend(frameon=False, loc="upper left")
    axes[0].set_ylabel("empirical Γ (smallest covering Γ)")
    save(fig, out, "figure2_synthetic_gamma")


def fig3(r, out, coat_rng, kr_rng):
    rep = (r / "platform_step4" / "report.txt").read_text(encoding="utf-8")
    boot = {m: tuple(map(float, re.search(rf"mu={m}\s+Gamma\* median ([\d.]+), 2.5%-97.5% \[([\d.]+), ([\d.]+)\]",
                                         rep).groups())) for m in ["gbdt", "logistic"]}
    st = pd.read_csv(r / "platform_step4" / "gamma_star_by_seed.csv")
    mean5 = st[(st.B == 500) & (st.post == "corr_gbdt")].groupby("mu").gamma_star.mean()
    rows = [("Coat: empirical Γ (user self-selection)", *coat_rng, None, C_COAT),
            ("KuaiRand: empirical Γ (platform exposure; upper anchor)", *kr_rng, None, C_KR),
            ("Platform Γ* (logistic value model)", boot["logistic"][1], boot["logistic"][2], mean5["logistic"], C_POST),
            ("Platform Γ* (GBDT value model)", boot["gbdt"][1], boot["gbdt"][2], mean5["gbdt"], C_PRE)]
    fig, ax = plt.subplots(figsize=(7.2, 2.4))
    for i, (lab, lo, hi, pt, c) in enumerate(rows[::-1]):
        ax.plot([lo, hi], [i, i], lw=7, color=c, alpha=0.65, solid_capstyle="butt")
        if pt is not None:
            ax.plot(pt, i, marker="|", color="k", ms=14, mew=1.5)
    ax.set_yticks(range(len(rows)))
    ax.set_yticklabels([x[0] for x in rows[::-1]])
    ax.set_xscale("log")
    ax.set_xlim(1, max(16, boot["gbdt"][2] * 1.1))
    ticks = [1, 1.5, 2, 3, 5, 8, 12]
    ax.set_xticks(ticks)
    ax.set_xticklabels([str(t) for t in ticks])
    ax.minorticks_off()
    ax.set_xlabel("Γ (odds-ratio bound on selection on the outcome)")
    save(fig, out, "figure3_gamma_anchors")


def fig4(r, out):
    cval = pd.read_csv(r / "coat_t4" / "value_by_rule.csv")
    ccv = pd.read_csv(r / "coat_t4" / "gamma_curves_value.csv")
    cvov = pd.read_csv(r / "coat_t4" / "gamma_curves_vov.csv")
    vov = pd.read_csv(r / "coat_t4" / "vov.csv")
    kval = pd.read_csv(r / "kuairand_click" / "value.csv")
    kcv = pd.read_csv(r / "kuairand_click" / "gamma_curves.csv")
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 6.2))
    # Coat value
    ax = axes[0, 0]
    for rule, col, lab in [("corr_gbdt", C_POST, "corr_gbdt"), ("pop", C_PRE, "popularity")]:
        c = ccv[(ccv.rule == rule) & np.isclose(ccv.q, 0.10) & (ccv.gamma < 1e8)].sort_values("gamma")
        v = cval[(cval.rule == rule) & np.isclose(cval.q, 0.10)].iloc[0]
        ax.fill_between(c.gamma, c.V_lo, c.V_hi, color=col, alpha=0.25, lw=0, label=f"{lab}: Γ interval")
        ax.axhspan(v.truth_lo, v.truth_hi, color=col, alpha=0.10, lw=0)
        ax.axhline(v.truth, color=col, ls="--", lw=1, label=f"{lab}: truth")
    ax.set_xscale("log"); ax.set_xlabel("Γ"); ax.set_ylabel("value of top-10% set")
    ax.set_title("Coat: value of the selected sets")
    ax.legend(frameon=False, loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=2)
    # Coat VoV
    ax = axes[0, 1]
    c = cvov[(cvov.post == "corr_gbdt") & np.isclose(cvov.q, 0.10) & (cvov.gamma < 1e8)].sort_values("gamma")
    v = vov[(vov.post == "corr_gbdt") & np.isclose(vov.q, 0.10)].iloc[0]
    ax.fill_between(c.gamma, c.VoV_lo, c.VoV_hi, color=C_POST, alpha=0.35, lw=0, label="VoV interval")
    ax.axhspan(v.truth_lo, v.truth_hi, color="k", alpha=0.10, lw=0)
    ax.axhline(v.truth, color="k", ls="--", lw=1, label="true VoV")
    ax.axhline(0, color="grey", lw=0.7)
    if np.isfinite(v.gamma_star_signflip):
        ax.axvline(v.gamma_star_signflip, color=C_PRE, ls=":", lw=1.2, label=f"Γ* = {v.gamma_star_signflip:.2f}")
    ax.set_xscale("log"); ax.set_xlabel("Γ"); ax.set_ylabel("VoV")
    ax.set_title("Coat: VoV (corr_gbdt − popularity)")
    ax.legend(frameon=False, loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=3)
    # KuaiRand
    for ax, mu, lab in [(axes[1, 0], "corr_gbdt", "gradient-boosted"), (axes[1, 1], "corr_logit", "logistic")]:
        for rule, col, rl in [("corr_gbdt", C_POST, "corr_gbdt"), ("pop", C_PRE, "popularity")]:
            c = kcv[(kcv.mu == mu) & (kcv.rule == rule) & (kcv.gamma < 1e8)].sort_values("gamma")
            t = kval[(kval.mu == mu) & np.isclose(kval.q, 0.05) & (kval.rule == rule)].truth.iloc[0]
            ax.fill_between(c.gamma, c.V_lo, c.V_hi, color=col, alpha=0.25, lw=0, label=f"{rl}: Γ interval")
            ax.axhline(t, color=col, ls="--", lw=1, label=f"{rl}: truth")
        ax.set_xscale("log"); ax.set_xlabel("Γ"); ax.set_ylabel("value of top-5% set")
        ax.set_title(f"KuaiRand: value model {lab}")
    h, l = axes[1, 0].get_legend_handles_labels()
    fig.tight_layout(rect=(0, 0.05, 1, 1), h_pad=3.0)
    fig.legend(h, l, loc="lower center", ncol=4, frameon=False)
    for ext in ("svg", "pdf"):
        fig.savefig(out / f"figure4_benchmarks_gamma.{ext}", bbox_inches="tight")
    plt.close(fig)
    print("written:", out / "figure4_benchmarks_gamma.svg")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    ap.add_argument("--out", default="figures")
    a = ap.parse_args()
    r, out = Path(a.results), Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    coat_rng, kr_rng = anchors(r)
    fig1(r, out, coat_rng, kr_rng)
    fig2(r, out)
    fig3(r, out, coat_rng, kr_rng)
    fig4(r, out)


if __name__ == "__main__":
    main()
