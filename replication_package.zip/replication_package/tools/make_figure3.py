# -*- coding: utf-8 -*-
"""
make_figure3.py — Figure 3: platform breakdown values Gamma* against the empirical Gamma of the benchmarks.

Usage (after run_all):  python tools/make_figure3.py --results results
Reads:  results/platform_step4/report.txt and gamma_star_by_seed.csv   (Gamma*, bootstrap interval, five-split mean)
        results/coat_t4/value_by_rule.csv                             (empirical Gamma on Coat)
        results/kuairand_click/value.csv, results/kuairand_longview/value.csv  (empirical Gamma on KuaiRand)
Writes: results/figure3_gamma_anchors.png
"""
import argparse
import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    ap.add_argument("--B", type=int, default=500)
    ap.add_argument("--q", type=float, default=0.05)
    r = Path(ap.parse_args().results)
    args = ap.parse_args()
    need = [r / "platform_step4" / "report.txt", r / "coat_t4" / "value_by_rule.csv", r / "kuairand_click" / "value.csv"]
    missing = [str(p) for p in need if not p.exists()]
    if missing:
        raise SystemExit("make_figure3: missing input file(s):\n  " + "\n  ".join(missing) +
                         f"\nPass --results <directory that contains platform_step4, coat_t4, kuairand_click> "
                         f"(current: {r.resolve()})")

    coat = pd.read_csv(r / "coat_t4" / "value_by_rule.csv")
    coat = coat[coat.q == coat.q.median()].gamma_cover_point
    kr = pd.concat([pd.read_csv(r / d / "value.csv") for d in ["kuairand_click", "kuairand_longview"]
                    if (r / d / "value.csv").exists()])
    kr = kr[(kr.mu == "corr_gbdt") & (kr.q == args.q)].gamma_cover

    rep = (r / "platform_step4" / "report.txt").read_text(encoding="utf-8")
    boot = {m: tuple(map(float, re.search(rf"mu={m}\s+Gamma\* median ([\d.]+), 2.5%-97.5% \[([\d.]+), ([\d.]+)\]",
                                         rep).groups())) for m in ["gbdt", "logistic"]}
    st = pd.read_csv(r / "platform_step4" / "gamma_star_by_seed.csv")
    mean5 = st[(st.B == args.B) & (st.post == "corr_gbdt")].groupby("mu").gamma_star.mean()

    rows = [("Coat: empirical Γ (user self-selection)", coat.min(), coat.max(), None, "C2"),
            ("KuaiRand: empirical Γ (platform exposure; upper anchor)", kr.min(), kr.max(), None, "C1"),
            ("Platform Γ* (logistic value model)", boot["logistic"][1], boot["logistic"][2], mean5["logistic"], "C0"),
            ("Platform Γ* (GBDT value model)", boot["gbdt"][1], boot["gbdt"][2], mean5["gbdt"], "C3")]
    fig, ax = plt.subplots(figsize=(7.5, 3.0))
    for i, (lab, lo, hi, pt, c) in enumerate(rows[::-1]):
        ax.plot([lo, hi], [i, i], lw=6, color=c, alpha=.6, solid_capstyle="butt")
        if pt is not None:
            ax.plot(pt, i, "k|", ms=14)
    ax.set_yticks(range(len(rows)))
    ax.set_yticklabels([x[0] for x in rows[::-1]], fontsize=8)
    ax.set_xscale("log")
    ax.set_xlabel("Γ (odds-ratio bound on selection on the outcome)")
    ax.set_xlim(1, max(16, boot["gbdt"][2] * 1.1))
    ticks = [1, 1.5, 2, 3, 5, 8, 12]
    ax.set_xticks(ticks)
    ax.set_xticklabels([str(t) for t in ticks])
    fig.tight_layout()
    fig.savefig(r / "figure3_gamma_anchors.png", dpi=220)
    for x in rows:
        print(f"{x[0]:58s} [{x[1]:.2f}, {x[2]:.2f}]" + (f"  mean {x[3]:.2f}" if x[3] is not None else ""))
    print("written:", r / "figure3_gamma_anchors.png")


if __name__ == "__main__":
    main()
