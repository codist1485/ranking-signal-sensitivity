# -*- coding: utf-8 -*-
"""
make_toy_data.py — generate small toy datasets with the same file names and schemas as the
platform data, Coat and KuaiRand-Pure, so that every script in this package can be run end to
end without the original data. Toy numbers are meaningless; use them only to check that the
pipeline runs.

Usage:  python tools/make_toy_data.py --out toy_data
Creates: toy_data/platform/*.csv, toy_data/coat/..., toy_data/kuairand/*.csv
"""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd


def platform(d, rng):
    d.mkdir(parents=True, exist_ok=True)
    nu, nj, na = 400, 3000, 20000
    uid = [f"u{i}" for i in range(nu)]
    jid = [f"j{i}" for i in range(nj)]
    edu = ["大专", "本科", "硕士", "高中", "中专", "博士"]   # education labels as they appear in the data
    pd.DataFrame(dict(
        user_id=uid, live_city_id=1, desire_jd_city_id="-", desire_jd_industry_id="a", desire_jd_type_id="b",
        desire_jd_salary_id=rng.choice(["100002000", "0200104000", "1000115000", "0"], nu),
        cur_industry_id="x", cur_jd_type="y", cur_salary_id="0", cur_degree_id=rng.choice(edu, nu),
        birthday=rng.choice([21, 24, 27, 30, 33, 36], nu), start_work_date=rng.integers(2000, 2019, nu),
        experience=["a|b|c"] * nu, resume_text=["# resume\ntext"] * nu)).to_csv(d / "user.csv", index=False)
    pd.DataFrame({
        "jd_no": jid, "jd_title": "t", "company_name": "-", "city": 1, "jd_sub_type": "s",
        "require_nums": rng.choice([1, 2, 5, 999], nj, p=[.4, .3, .29, .01]),
        "max_salary": rng.integers(5000, 20000, nj), "min_salary": rng.integers(2000, 5000, nj),
        "start_date": "20190322", "end_date": "20190422", "is_travel": rng.integers(0, 3, nj),
        "min_years": rng.choice([103, 305, 510, 1099, -1, 0, 1], nj), "key": "",
        "min_edu_level": rng.choice(edu + ["\\N"], nj), "max_edu_level": "\\N", "is_mangerial": "",
        "resume_language_required": "", "job_description": ["description"] * nj, "job_text": "x"}
    ).to_csv(d / "job.csv", index=False)
    a = pd.DataFrame(dict(user_id=rng.choice(uid, na), jd_no=rng.choice(jid, na))).drop_duplicates()
    n = len(a)
    dl = rng.random(n) < .3
    a["browsed"] = (dl | (rng.random(n) < .3)).astype(int)
    a["delivered"] = dl.astype(int)
    a["satisfied"] = (dl & (rng.random(n) < .46)).astype(int)
    a.to_csv(d / "action.csv", index=False)
    sub = a[a.delivered == 1].sample(300, random_state=0)
    rj = pd.DataFrame(dict(user_id=sub.user_id, rank=rng.integers(1, 101, 300), jd_no=sub.jd_no,
                           satisfied=rng.choice([-1, 0, 1], 300)))
    rj.to_csv(d / "rank_job.csv", index=False)
    rj[["jd_no", "rank", "user_id", "satisfied"]].to_csv(d / "rank_resume.csv", index=False)


def coat(d, rng):
    f = d / "user_item_features"
    f.mkdir(parents=True, exist_ok=True)
    U, I = 290, 300
    umap = (["gender:men", "gender:women"] + [f"age:{a}" for a in ["20-30", "30-40", "40-50", "50-60", "over 60", "under 20"]]
            + ["location:rural", "location:suburban", "location:urban", "fashioninterest:moderately",
               "fashioninterest:not at all", "fashioninterest:very"])
    imap = (["gender:men", "gender:women"] + [f"jackettype:t{k}" for k in range(16)] +
            [f"color:c{k}" for k in range(13)] + ["onfrontpage:yes", "onfrontpage:no"])

    def oh(n, groups):
        M = np.zeros((n, sum(groups)))
        o = 0
        for g in groups:
            M[np.arange(n), o + rng.integers(0, g, n)] = 1
            o += g
        return M
    uf, itf = oh(U, [2, 6, 3, 3]), oh(I, [2, 16, 13, 2])
    true = rng.normal(0, 1, (U, I)) + (uf[:, :2] @ itf[:, :2].T) * 0.8
    R = np.digitize(true, np.quantile(true, [0.35, 0.55, 0.75, 0.9])) + 1
    train, test = np.zeros((U, I)), np.zeros((U, I))
    for u in range(U):
        p = np.exp(0.8 * R[u])
        p /= p.sum()
        tr = rng.choice(I, 24, replace=False, p=p)
        train[u, tr] = R[u, tr]
        te = rng.choice(I, 16, replace=False)
        test[u, te] = R[u, te]
    np.savetxt(d / "train.ascii", train, fmt="%d")
    np.savetxt(d / "test.ascii", test, fmt="%d")
    np.savetxt(d / "propensities.ascii", np.clip(rng.uniform(0, .16, (U, I)), .0025, .69))
    np.savetxt(f / "user_features.ascii", uf, fmt="%d")
    np.savetxt(f / "item_features.ascii", itf, fmt="%d")
    (f / "user_features_map.txt").write_text("\n".join(umap))
    (f / "item_features_map.txt").write_text("\n".join(imap))


def kuairand(d, rng):
    d.mkdir(parents=True, exist_ok=True)
    U, V = 600, 400
    uq, vq = rng.normal(size=U), rng.normal(size=V)

    def logs(n, biased):
        u = rng.integers(0, U, n)
        if biased:
            p = np.exp(1.2 * vq)
            v = rng.choice(V, n, p=p / p.sum())
        else:
            v = rng.integers(0, V, n)
        D = (rng.random(n) < 1 / (1 + np.exp(-(-1.5 + 0.8 * uq[u] + 0.9 * vq[v])))).astype(int)
        z = np.zeros(n, int)
        return pd.DataFrame(dict(user_id=u, video_id=v, date=20220422, hourmin=1200, time_ms=0, is_click=D,
                                 is_like=z, is_follow=z, is_comment=z, is_forward=z, is_hate=z,
                                 long_view=D * (rng.random(n) < .6), play_time_ms=z, duration_ms=z,
                                 profile_stay_time=z, comment_stay_time=z, is_profile_enter=z,
                                 is_rand=int(not biased), tab=1))
    logs(40000, True).to_csv(d / "log_standard_4_08_to_4_21_pure.csv", index=False)
    logs(15000, True).to_csv(d / "log_standard_4_22_to_5_08_pure.csv", index=False)
    logs(30000, False).to_csv(d / "log_random_4_22_to_5_08_pure.csv", index=False)
    uf = pd.DataFrame(dict(user_id=range(U), user_active_degree=rng.choice(["full_active", "high_active"], U),
                           is_lowactive_period=0, is_live_streamer=rng.choice([1, -124], U),
                           is_video_author=rng.integers(0, 2, U), follow_user_num=rng.integers(0, 500, U),
                           follow_user_num_range="x", fans_user_num=rng.integers(0, 500, U), fans_user_num_range="x",
                           friend_user_num=rng.integers(0, 50, U), friend_user_num_range="x",
                           register_days=rng.integers(1, 2000, U), register_days_range="x"))
    for k in range(18):
        uf[f"onehot_feat{k}"] = rng.integers(0, 5, U)
    uf.to_csv(d / "user_features_pure.csv", index=False)
    pd.DataFrame(dict(video_id=range(V), author_id=1, video_type=rng.choice(["NORMAL", "AD"], V, p=[.9, .1]),
                      upload_dt="2022-04-10", upload_type=rng.choice(["a", "b"], V), visible_status=0,
                      video_duration=rng.integers(5000, 200000, V), server_width=720, server_height=1280,
                      music_id=1, music_type=rng.integers(0, 10, V),
                      tag=[str(rng.integers(1, 40)) for _ in range(V)])).to_csv(d / "video_features_basic_pure.csv", index=False)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="toy_data")
    out = Path(ap.parse_args().out)
    rng = np.random.default_rng(0)
    platform(out / "platform", rng)
    coat(out / "coat", rng)
    kuairand(out / "kuairand", rng)
    print("toy data written to", out.resolve())
