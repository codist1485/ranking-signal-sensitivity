# -*- coding: utf-8 -*-
"""
kuairand_experiment.py — KuaiRand-Pure: validation under recommender-exposure selection (Section 6.3, Table 11).

Usage:
  python kuairand_experiment.py --data <KUAIRAND_DATA_DIR> --out results/kuairand_click
  python kuairand_experiment.py --data <KUAIRAND_DATA_DIR> --outcome long_view --out results/kuairand_longview

Design (covariate-shift formulation; the four pre-registered criteria mirror the Coat experiment)
  history window   log_standard_4_08_to_4_21  -> history features and pi_pre only (no leakage)
  visible data     log_standard_4_22_to_5_08  -> exposures chosen by the recommender (H = 1), outcome observed
  target population log_random_4_22_to_5_08   -> random insertions in the same period ("randomly reachable"
                                                 user-video pairs); outcomes used only for truth, never for fitting
  pi_pre           the video's click count in the history window (popularity signal)
  fitted rules     corr_logit (logistic), corr_gbdt (HistGradientBoosting), ipw (logistic, density-ratio weighted),
                   all fitted on the visible data
  selected set     top q of the target-population units by score (q = 1%, 5%, 10%); visible units above the
                   same threshold enter the estimators
Estimators
  naive    mean D of visible units in the selected set
  ipw      self-normalized importance weighting, w(x) ∝ P(random | x)/P(standard | x), from a logistic classifier
  dr       doubly robust: mean mu over target units in the set + weighted mean residual of visible units
  impute   mean mu over target units in the set (Gamma = 1 centre); mu = GBDT (main) or logistic
  truth    mean D of random exposures in the selected set
Pre-registered criteria
  C1 ranking insensitivity: 95% CI of AUC(ipw) - AUC(corr_logit) on random exposures contains 0
  C2 value sensitivity: naive overstates the truth and |bias(DR)| < |bias(naive)|
  C3 empirical Gamma: smallest Gamma whose interval covers the truth
  C4 sign agreement: sign of the true VoV equals the sign of the DR estimate
All models are cross-fitted over five user folds; uncertainty from a user-clustered bootstrap with the selection
threshold fixed at its full-sample value.
Dependencies: numpy, pandas, scikit-learn, matplotlib. Memory about 4-6 GB; runtime about 5-25 minutes.
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

LOGS = dict(hist="log_standard_4_08_to_4_21_pure.csv", std="log_standard_4_22_to_5_08_pure.csv",
            rand="log_random_4_22_to_5_08_pure.csv")
RULES = ["pop", "corr_logit", "corr_gbdt", "ipw"]
POST = "corr_gbdt"
GRID = np.unique(np.concatenate([np.exp(np.linspace(0, np.log(50), 400)), [1e9]]))
lines = []


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s, flush=True)
    lines.append(s)


def read_log(p, outcome):
    use = ["user_id", "video_id", outcome]
    d = pd.read_csv(p, usecols=use)
    return d.rename(columns={outcome: "D"})


def build_features(data_dir, outcome):
    d = Path(data_dir)
    hist = read_log(d / LOGS["hist"], outcome)
    std = read_log(d / LOGS["std"], outcome)
    rnd = read_log(d / LOGS["rand"], outcome)
    # repeated standard exposures of a user-video pair are collapsed (maximum), as for the platform data
    std = std.groupby(["user_id", "video_id"], as_index=False).D.max()
    std["src"] = 1
    rnd["src"] = 0

    # ---- static features
    uf = pd.read_csv(d / "user_features_pure.csv")
    vf = pd.read_csv(d / "video_features_basic_pure.csv")
    U = pd.DataFrame({"user_id": uf.user_id})
    U["u_active"] = uf.user_active_degree.astype("category").cat.codes
    for c in ["is_lowactive_period", "is_live_streamer", "is_video_author"]:
        U[c] = pd.to_numeric(uf[c], errors="coerce").clip(lower=0)
    for c in ["follow_user_num", "fans_user_num", "friend_user_num", "register_days"]:
        U["u_log_" + c] = np.log1p(pd.to_numeric(uf[c], errors="coerce").clip(lower=0))
    for k in range(18):
        U[f"u_oh{k}"] = pd.to_numeric(uf[f"onehot_feat{k}"], errors="coerce")
    V = pd.DataFrame({"video_id": vf.video_id})
    V["v_is_normal"] = (vf.video_type == "NORMAL").astype(float)
    V["v_upload"] = vf.upload_type.astype("category").cat.codes
    V["v_log_dur"] = np.log1p(pd.to_numeric(vf.video_duration, errors="coerce"))
    V["v_aspect"] = pd.to_numeric(vf.server_height, errors="coerce") / pd.to_numeric(vf.server_width, errors="coerce")
    V["v_music_type"] = pd.to_numeric(vf.music_type, errors="coerce")
    V["v_tag"] = pd.to_numeric(vf.tag.astype(str).str.split(",").str[0], errors="coerce")

    # ---- history features (8-21 April only)
    p0 = hist.D.mean()
    a = 20.0
    hu = hist.groupby("user_id").D.agg(["sum", "count"]).reset_index()
    hv = hist.groupby("video_id").D.agg(["sum", "count"]).reset_index()
    U = U.merge(pd.DataFrame({"user_id": hu.user_id.values,
                              "u_hist_rate": ((hu["sum"] + a * p0) / (hu["count"] + a)).values,
                              "u_hist_log_n": np.log1p(hu["count"]).values}), on="user_id", how="left")
    V = V.merge(pd.DataFrame({"video_id": hv.video_id.values,
                              "v_hist_rate": ((hv["sum"] + a * p0) / (hv["count"] + a)).values,
                              "v_hist_log_n": np.log1p(hv["count"]).values, "v_hist_pos": hv["sum"].values}),
                on="video_id", how="left")
    V["v_hist_pos"] = V.v_hist_pos.fillna(0)
    V[["v_hist_rate"]] = V[["v_hist_rate"]].fillna(p0)
    U[["u_hist_rate"]] = U[["u_hist_rate"]].fillna(p0)
    V["v_hist_log_n"] = V.v_hist_log_n.fillna(0)
    U["u_hist_log_n"] = U.u_hist_log_n.fillna(0)

    allp = pd.concat([std, rnd], ignore_index=True)
    allp = allp.merge(U, on="user_id", how="left").merge(V, on="video_id", how="left")
    lin_cols = (["u_hist_rate", "u_hist_log_n", "v_hist_rate", "v_hist_log_n", "v_log_dur", "v_is_normal",
                 "v_aspect", "is_lowactive_period", "is_live_streamer", "is_video_author"] +
                [c for c in U.columns if c.startswith("u_log_")])
    gb_cols = lin_cols + ["u_active", "v_upload", "v_music_type", "v_tag"] + [f"u_oh{k}" for k in range(18)]
    return allp, lin_cols, gb_cols, dict(n_hist=len(hist), n_std=len(std), n_rand=len(rnd), p0_hist=p0)


def standardize(Xtr, Xte):
    mu = np.nanmean(Xtr, axis=0)
    Xtr = np.where(np.isnan(Xtr), mu, Xtr)
    Xte = np.where(np.isnan(Xte), mu, Xte)
    sd = Xtr.std(axis=0)
    sd[sd == 0] = 1
    return (Xtr - mu) / sd, (Xte - mu) / sd


def cross_fit(allp, lin_cols, gb_cols, folds, seed):
    users = allp.user_id.unique()
    rng = np.random.default_rng(seed)
    fu = dict(zip(users, rng.permutation(np.arange(len(users)) % folds)))
    fold = allp.user_id.map(fu).values
    src = allp.src.values
    D = allp.D.values.astype(float)
    XL = allp[lin_cols].values.astype(np.float64)
    XG = allp[gb_cols].values.astype(np.float32)
    n = len(allp)
    out = {k: np.full(n, np.nan) for k in ["corr_logit", "corr_gbdt", "ipw", "c_std"]}
    for k in range(folds):
        trm, tem = fold != k, fold == k
        XLtr, XLte = standardize(XL[trm], XL[tem])
        s_tr = src[trm]
        # classifier separating standard from random exposures -> density ratio
        clf = LogisticRegression(max_iter=1000).fit(XLtr, s_tr)
        out["c_std"][tem] = clf.predict_proba(XLte)[:, 1]
        c_tr = clf.predict_proba(XLtr)[:, 1]
        vis = s_tr == 1
        y = D[trm][vis]
        m = LogisticRegression(max_iter=1000).fit(XLtr[vis], y)
        out["corr_logit"][tem] = m.predict_proba(XLte)[:, 1]
        g = HistGradientBoostingClassifier(max_iter=300, learning_rate=0.1, max_leaf_nodes=31,
                                           random_state=seed).fit(XG[trm][vis], y)
        out["corr_gbdt"][tem] = g.predict_proba(XG[tem])[:, 1]
        ratio = (1 - c_tr[vis]) / np.clip(c_tr[vis], 1e-6, None)
        ratio = np.clip(ratio, *np.percentile(ratio, [1, 99]))
        m = LogisticRegression(max_iter=1000).fit(XLtr[vis], y, sample_weight=ratio / ratio.mean())
        out["ipw"][tem] = m.predict_proba(XLte)[:, 1]
        log(f"  fold {k} done")
    for kname, v in out.items():
        allp[kname] = v
    allp["pop"] = allp.v_hist_pos.values + np.random.default_rng(seed + 1).uniform(0, 1e-3, n)
    allp["w"] = (1 - allp.c_std) / np.clip(allp.c_std, 1e-6, None)
    return allp


def band(p, G=GRID):
    p = np.clip(p, 1e-9, 1 - 1e-9)[None, :]
    g = G[:, None]
    return (p / (p + g * (1 - p))).mean(1), (g * p / (g * p + 1 - p)).mean(1)


def estimates(allp, rule, q, mu_col, wclip):
    rnd = allp[allp.src == 0]
    std = allp[allp.src == 1]
    thr = np.quantile(rnd[rule].values, 1 - q)
    rs = rnd[rnd[rule] >= thr]
    ss = std[std[rule] >= thr]
    w = np.clip(ss.w.values, *wclip)
    r = dict(rule=rule, q=q, mu=mu_col, thr=thr, n_pop_set=len(rs), n_vis_set=len(ss),
             truth=rs.D.mean(), naive=ss.D.mean(),
             ipw=(w * ss.D.values).sum() / w.sum(),
             impute=rs[mu_col].mean(),
             dr=rs[mu_col].mean() + (w * (ss.D.values - ss[mu_col].values)).sum() / w.sum())
    return r, rs, ss, thr


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--outcome", default="is_click", choices=["is_click", "long_view"])
    ap.add_argument("--qs", type=float, nargs="+", default=[0.01, 0.05, 0.10])
    ap.add_argument("--q_main", type=float, default=0.05)
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--nboot", type=int, default=500)
    args = ap.parse_args()
    t0 = time.time()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    allp, lin_cols, gb_cols, info = build_features(args.data, args.outcome)
    log(f"KUAIRAND  outcome={args.outcome}  history {info['n_hist']:,}  visible (standard, distinct pairs) {info['n_std']:,}  "
        f"target population (random) {info['n_rand']:,}  [{time.time() - t0:.0f}s]")
    allp = cross_fit(allp, lin_cols, gb_cols, args.folds, args.seed)
    rnd = allp[allp.src == 0]
    std = allp[allp.src == 1]
    wv = std.w.values
    wclip = tuple(np.percentile(wv, [1, 99]))
    wc = np.clip(wv, *wclip)
    diag = dict(pos_rate_visible=float(std.D.mean()), pos_rate_random=float(rnd.D.mean()),
                clf_auc_std_vs_rand=float(roc_auc_score(allp.src, allp.c_std)),
                w_clip=list(map(float, wclip)), ESS_frac=float(wc.sum() ** 2 / (wc ** 2).sum() / len(wc)),
                mu_gbdt_auc_random=float(roc_auc_score(rnd.D, rnd.corr_gbdt)),
                mu_logit_auc_random=float(roc_auc_score(rnd.D, rnd.corr_logit)))
    log("Diagnostics:", json.dumps(diag))

    # ---- AUC (C1)
    auc_rows = []
    for r in RULES:
        auc_rows.append(dict(rule=r, auc_oracle_random=roc_auc_score(rnd.D, rnd[r]),
                             auc_visible=roc_auc_score(std.D, std[r]),
                             auc_visible_weighted=roc_auc_score(std.D, std[r], sample_weight=wc)))
    auc = pd.DataFrame(auc_rows)
    users = allp.user_id.unique()
    uidx = {u: i for i, u in enumerate(users)}
    rnd_u = rnd.user_id.map(uidx).values
    rng = np.random.default_rng(7)
    diffs = []
    groups = pd.Series(np.arange(len(rnd))).groupby(rnd_u).apply(np.array).to_dict()
    keys = np.array(list(groups.keys()))
    for _ in range(min(args.nboot, 200)):
        pick = rng.choice(keys, len(keys))
        idx = np.concatenate([groups[k] for k in pick])
        yy = rnd.D.values[idx]
        diffs.append(roc_auc_score(yy, rnd.ipw.values[idx]) - roc_auc_score(yy, rnd.corr_logit.values[idx]))
    dlo, dhi = np.percentile(diffs, [2.5, 97.5])
    log("\n[AUC] on random exposures (truth), on visible data, and weighted on visible data")
    log(auc.round(4).to_string(index=False))
    dpt = auc.set_index("rule").auc_oracle_random
    log(f"C1: AUC_random(ipw) − AUC_random(corr_logit) = {dpt['ipw'] - dpt['corr_logit']:+.4f}, "
        f"user-clustered bootstrap 95% CI [{dlo:+.4f}, {dhi:+.4f}] -> {'MET' if dlo <= 0 <= dhi else 'NOT MET'}")

    # ---- value and Gamma (C2-C4)
    rows, curves = [], []
    for mu_col in ["corr_gbdt", "corr_logit"]:
        for q in args.qs:
            sets = {}
            for r in RULES:
                est, rs, ss, thr = estimates(allp, r, q, mu_col, wclip)
                lo, hi = band(rs[mu_col].values)
                cover = GRID[(lo <= est["truth"]) & (hi >= est["truth"])]
                est["gamma_cover"] = float(cover[0]) if len(cover) else np.inf
                rows.append(est)
                sets[r] = (lo, hi)
                if q == args.q_main:
                    for g, l, h in zip(GRID, lo, hi):
                        curves.append(dict(mu=mu_col, rule=r, gamma=g, V_lo=l, V_hi=h))
            vlo = sets[POST][0] - sets["pop"][1]
            hit = np.flatnonzero(vlo <= 0)
            for rr in rows[-len(RULES):]:
                rr["gamma_star_vs_pop"] = float(GRID[hit[0]]) if (rr["rule"] == POST and len(hit) and vlo[0] > 0) else np.nan
    val = pd.DataFrame(rows)
    for c in ["naive", "ipw", "dr", "impute"]:
        val[f"bias_{c}"] = val[c] - val.truth
    val["dr_reduction"] = 1 - val.bias_dr.abs() / val.bias_naive.abs()
    val.to_csv(out / "value.csv", index=False)
    pd.DataFrame(curves).to_csv(out / "gamma_curves.csv", index=False)
    log("\n[Value] selected set of each rule: truth, naive, IPW, DR, imputation; empirical Gamma (smallest covering Gamma)")
    log(val[["mu", "q", "rule", "n_pop_set", "n_vis_set", "truth", "naive", "ipw", "dr", "impute",
             "dr_reduction", "gamma_cover", "gamma_star_vs_pop"]].round(4).to_string(index=False))

    # ---- user-clustered bootstrap (threshold fixed): truth, naive, DR and VoV
    log(f"\n[Bootstrap] mu=corr_gbdt, q={args.q_main}, {args.nboot} user-clustered replicates (threshold fixed)")
    mu_col = "corr_gbdt"
    agg = {}
    for r in RULES:
        thr = val[(val.rule == r) & (val.q == args.q_main) & (val.mu == mu_col)].thr.iloc[0]
        rin = (rnd[r] >= thr).values
        sin = (std[r] >= thr).values
        wst = np.clip(std.w.values, *wclip)
        R = pd.DataFrame({"u": rnd.user_id.values, "n": rin * 1.0, "y": rin * rnd.D.values,
                          "m": rin * rnd[mu_col].values}).groupby("u").sum()
        S = pd.DataFrame({"u": std.user_id.values, "n": sin * 1.0, "y": sin * std.D.values,
                          "w": sin * wst, "wr": sin * wst * (std.D.values - std[mu_col].values)}).groupby("u").sum()
        agg[r] = (R.reindex(users).fillna(0).values, S.reindex(users).fillna(0).values)
    rng = np.random.default_rng(11)
    rec = []
    for _ in range(args.nboot):
        pk = rng.integers(0, len(users), len(users))
        row = {}
        for r in RULES:
            Rm, Sm = agg[r][0][pk].sum(0), agg[r][1][pk].sum(0)
            row[(r, "truth")] = Rm[1] / Rm[0]
            row[(r, "naive")] = Sm[1] / Sm[0]
            row[(r, "dr")] = Rm[2] / Rm[0] + Sm[3] / Sm[2]
        rec.append(row)
    bt = pd.DataFrame(rec)
    for k in ["truth", "naive", "dr"]:
        v = bt[(POST, k)] - bt[("pop", k)]
        log(f"  VoV({POST} − pop) {k:6s}: 95% CI [{np.percentile(v, 2.5):+.4f}, {np.percentile(v, 97.5):+.4f}]")
    for r in RULES:
        b = bt[(r, "naive")] - bt[(r, "truth")]
        bd = bt[(r, "dr")] - bt[(r, "truth")]
        log(f"  {r:11s} naive bias 95% CI [{np.percentile(b, 2.5):+.4f}, {np.percentile(b, 97.5):+.4f}] | "
            f"DR bias [{np.percentile(bd, 2.5):+.4f}, {np.percentile(bd, 97.5):+.4f}]")

    # ---- summary of the four criteria
    vm = val[(val.mu == "corr_gbdt") & (val.q == args.q_main)].set_index("rule")
    log(f"\n[Pre-registered criteria] mu=corr_gbdt, q={args.q_main}")
    log(f"  C1: see above (AUC difference ipw - corr_logit on random exposures)")
    for r in RULES:
        ok = vm.loc[r, "bias_naive"] > 0 and abs(vm.loc[r, "bias_dr"]) < abs(vm.loc[r, "bias_naive"])
        log(f"  C2 {r:11s}: naive bias {vm.loc[r, 'bias_naive']:+.4f}, DR bias {vm.loc[r, 'bias_dr']:+.4f}, "
            f"DR bias reduction {vm.loc[r, 'dr_reduction']:+.2f} -> {'MET' if ok else 'NOT MET'}")
        log(f"  C3 {r:11s}: empirical Gamma = {vm.loc[r, 'gamma_cover']:.3g}")
    tv = vm.loc[POST, "truth"] - vm.loc["pop", "truth"]
    dv = vm.loc[POST, "dr"] - vm.loc["pop", "dr"]
    log(f"  C4: true VoV {tv:+.4f}, DR VoV {dv:+.4f}, naive VoV {vm.loc[POST, 'naive'] - vm.loc['pop', 'naive']:+.4f}"
        f" -> {'MET' if np.sign(tv) == np.sign(dv) else 'NOT MET'}; Gamma*(VoV) = {vm.loc[POST, 'gamma_star_vs_pop']:.3g}")

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        cv = pd.DataFrame(curves)
        fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
        for ax, mu_col in zip(axes, ["corr_gbdt", "corr_logit"]):
            for r, col in [(POST, "C0"), ("pop", "C3")]:
                c = cv[(cv.mu == mu_col) & (cv.rule == r) & (cv.gamma < 1e8)].sort_values("gamma")
                ax.fill_between(c.gamma, c.V_lo, c.V_hi, color=col, alpha=0.25, label=f"{r}: Γ band")
                t = val[(val.mu == mu_col) & (val.q == args.q_main) & (val.rule == r)].truth.iloc[0]
                ax.axhline(t, color=col, ls="--", lw=1.2, label=f"{r}: truth (random exposure)")
            ax.set_xscale("log")
            ax.set_xlabel("Γ")
            ax.set_ylabel(f"value of top-{args.q_main:.0%} set")
            ax.set_title(f"KuaiRand ({args.outcome}), value model: {mu_col}")
            ax.legend(fontsize=7)
        fig.tight_layout()
        fig.savefig(out / "gamma_plot_kuairand.png", dpi=200)
    except Exception as ex:
        log("figure skipped:", ex)
    log(f"\nTotal runtime {time.time() - t0:.0f} s")
    (out / "report.txt").write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    main()
