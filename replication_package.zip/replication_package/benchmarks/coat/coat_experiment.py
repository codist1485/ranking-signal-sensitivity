# -*- coding: utf-8 -*-
"""
coat_experiment.py — Coat: validation under user self-selection (Section 6.2, Table 10).
Purpose
-------
Validate, on data with a REAL selection mechanism and an unbiased random-exposure
test set, the claims of the paper:
  C1  ranking metrics are insensitive to selection correction (IPW vs unweighted fit);
  C2  value metrics are sensitive to selection: the naive value of a selected set is
      biased, and IPW / AIPW reduce the bias;
  C3  the Gamma-sensitivity band  [V-(Gamma), V+(Gamma)]  covers the true value at some
      Gamma; the smallest such Gamma ("empirical Gamma") calibrates the platform analysis;
  C4  the sign of the true value of validation (VoV) agrees with the model-based sign.

The criteria are fixed BEFORE running (see report section "Pre-registered criteria").

Mapping to the paper
-------------------------
  population      all 290 x 300 user-item pairs
  H (visibility)  pair rated in train.ascii (user self-selected, MNAR)
  D (outcome)     rating >= threshold (default 4)
  truth           test.ascii: 16 uniformly random items per user (random exposure);
                  an unbiased sample of the population, used ONLY for truth
  pi_pre          item popularity in the self-selected log (unaudited platform signal)
  fitted rules    corr_X, corr_logit, corr_gbdt, corr_gbdt_cf, ipw (fitted on H=1 rows)

Estimators (Section 3.1):
  naive (H=1 mean), IPW (Hajek, w = H / clip(e, 0.02, 0.98)),
  AIPW  mean of mu + H/e (D - mu), with mu logistic (main) or GBDT,
  regression imputation  mean of H*D + (1-H)*mu   (the Gamma = 1 centre of the band),
  Manski bounds (unobserved outcomes set to 0 / 1).

Gamma sensitivity model (pattern-mixture / odds-ratio):
  for an unobserved pair with MAR prediction p = mu(x),
  P(D=1 | x, H=0) lies in [ p / (p + G(1-p)),  G p / (G p + 1 - p) ].
  G = 1 reproduces regression imputation under MAR; G -> inf gives the Manski bounds.

All model-based quantities are cross-fitted over user folds (K = 5 by default):
every score / propensity / outcome prediction for a user comes from models fitted
on the other users only. test.ascii is never used for fitting.

Usage
-----
  python coat_experiment.py --data "PATH\\TO\\coat" --out results_coat_t4
  python coat_experiment.py --data "PATH\\TO\\coat" --threshold 3 --out results_coat_t3

Dependencies: numpy, pandas, scikit-learn, matplotlib
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

CLIP_EVAL = (0.02, 0.98)      # evaluation / value-estimator clipping
CLIP_FIT = (1e-3, 1 - 1e-3)   # clipping inside the ipw rule's weighted fit
GBDT_KW = dict(n_estimators=200, max_depth=3, learning_rate=0.1, subsample=0.8)
FITTED_RULES = ["corr_X", "corr_logit", "corr_gbdt", "corr_gbdt_cf", "ipw"]
ALL_RULES = ["pop"] + FITTED_RULES
POST_MAIN = "corr_gbdt"       # the audited policy


# --------------------------------------------------------------------------- #
# Data
# --------------------------------------------------------------------------- #
def read_map(p):
    return [ln.strip() for ln in Path(p).read_text(encoding="utf-8").splitlines() if ln.strip()]


def load_coat(root):
    root = Path(root)
    fdir = root / "user_item_features"
    d = dict(
        train=np.loadtxt(root / "train.ascii"),
        test=np.loadtxt(root / "test.ascii"),
        prop=np.loadtxt(root / "propensities.ascii"),
        uf=np.loadtxt(fdir / "user_features.ascii"),
        itf=np.loadtxt(fdir / "item_features.ascii"),
        umap=read_map(fdir / "user_features_map.txt"),
        imap=read_map(fdir / "item_features_map.txt"),
    )
    U, I = d["train"].shape
    assert d["test"].shape == (U, I) and d["prop"].shape == (U, I)
    assert d["uf"].shape[0] == U and d["itf"].shape[0] == I
    assert d["uf"].shape[1] == len(d["umap"]) and d["itf"].shape[1] == len(d["imap"])
    return d


def build_pairs(d, threshold):
    train, test = d["train"], d["test"]
    U, I = train.shape
    u = np.repeat(np.arange(U), I)
    i = np.tile(np.arange(I), U)
    r_tr, r_te = train.ravel(), test.ravel()
    H = (r_tr > 0).astype(int)
    D_obs = np.where(H == 1, (r_tr >= threshold).astype(float), np.nan)
    in_test = r_te > 0
    D_true = np.where(in_test, (r_te >= threshold).astype(float), np.nan)

    # features: user one-hot, item one-hot, gender match
    uf, itf = d["uf"], d["itf"]
    um = {n: k for k, n in enumerate(d["umap"])}
    im = {n: k for k, n in enumerate(d["imap"])}
    gm = np.zeros(U * I)
    for g in ("men", "women"):
        ku, ki = um.get(f"gender:{g}"), im.get(f"gender:{g}")
        if ku is not None and ki is not None:
            gm += uf[u, ku] * itf[i, ki]
    X = np.column_stack([uf[u], itf[i], gm])
    xnames = [f"u_{n}" for n in d["umap"]] + [f"i_{n}" for n in d["imap"]] + ["gender_match"]

    pop_item = train.astype(bool).sum(axis=0)          # platform signal: item popularity
    return pd.DataFrame(dict(u=u, i=i, H=H, D_obs=D_obs, in_test=in_test, D_true=D_true,
                             pop=pop_item[i].astype(float), e_auth=d["prop"].ravel())), X, xnames


# --------------------------------------------------------------------------- #
# Cross-fitted models
# --------------------------------------------------------------------------- #
def pop_feature(H, i, u, fit_users_mask, n_items, n_users):
    """log1p of item popularity computed on fitting-fold users only, leave-one-out
    for fitting rows; standardised. Avoids using held-out users' visibility."""
    cnt = np.bincount(i[fit_users_mask], weights=H[fit_users_mask], minlength=n_items)
    n_fit_users = len(np.unique(u[fit_users_mask]))
    raw = cnt[i] - np.where(fit_users_mask, H, 0)
    raw = raw / max(n_fit_users, 1) * n_users          # rescale to full-population counts
    f = np.log1p(raw)
    return (f - f[fit_users_mask].mean()) / (f[fit_users_mask].std() + 1e-12)



def item_te(H, D, i, src_mask, n_items, a=5.0):
    """Smoothed item mean of D over H=1 rows in src_mask (no row outside src_mask
    contributes). Returns the encoding for every row."""
    m = src_mask & (H == 1)
    s = np.bincount(i[m], weights=D[m], minlength=n_items)
    c = np.bincount(i[m], minlength=n_items).astype(float)
    p0 = D[m].mean() if m.any() else 0.0
    return ((s + a * p0) / (c + a))[i]


def item_te_crossfit(H, D, i, u, fit_mask, n_items, seed, inner=4):
    """Leak-free item target encoding:
    held-out rows get the encoding from all fitting-fold users; fitting rows get it
    from the OTHER inner folds of fitting users only, so no row's own outcome
    (or its user's outcomes) enters its own feature."""
    te = item_te(H, D, i, fit_mask, n_items)
    fit_users = np.unique(u[fit_mask])
    rng = np.random.default_rng(seed)
    inner_of = dict(zip(fit_users, rng.permutation(np.arange(len(fit_users)) % inner)))
    ifold = np.array([inner_of.get(x, -1) for x in u])
    for g in range(inner):
        tgt = fit_mask & (ifold == g)
        te[tgt] = item_te(H, D, i, fit_mask & (ifold != g), n_items)[tgt]
    return te

def cross_fit(df, X, folds, seed):
    rng = np.random.default_rng(seed)
    users = np.unique(df.u.values)
    fold_of_user = rng.permutation(np.arange(len(users)) % folds)
    fold = fold_of_user[df.u.values]
    n = len(df)
    H = df.H.values
    D = np.nan_to_num(df.D_obs.values)
    out = {k: np.full(n, np.nan) for k in
           ["e", "mu_logit", "mu_gbdt"] + FITTED_RULES}
    n_items = df.i.max() + 1
    for k in range(folds):
        tr = fold != k
        te = ~tr
        pf = pop_feature(H, df.i.values, df.u.values, tr, n_items, len(users))
        XP = np.column_stack([X, pf])
        te_enc = item_te_crossfit(H, D, df.i.values, df.u.values, tr, n_items, seed + k)
        XC = np.column_stack([XP, te_enc])

        # propensity e = P(H=1 | X, pop) on all fitting-fold pairs
        pm = LogisticRegression(max_iter=2000).fit(XP[tr], H[tr])
        out["e"][te] = pm.predict_proba(XP[te])[:, 1]
        e_tr = np.clip(pm.predict_proba(XP[tr])[:, 1], *CLIP_FIT)

        obs = tr & (H == 1)
        y = D[obs]
        m = LogisticRegression(max_iter=2000).fit(X[obs], y)
        out["corr_X"][te] = m.predict_proba(X[te])[:, 1]
        m = LogisticRegression(max_iter=2000).fit(XP[obs], y)
        out["corr_logit"][te] = m.predict_proba(XP[te])[:, 1]
        out["mu_logit"][te] = out["corr_logit"][te]      # AIPW-logistic value model
        m = GradientBoostingClassifier(random_state=seed, **GBDT_KW).fit(XP[obs], y)
        out["corr_gbdt"][te] = m.predict_proba(XP[te])[:, 1]
        out["mu_gbdt"][te] = out["corr_gbdt"][te]        # AIPW-GBDT value model
        m = GradientBoostingClassifier(random_state=seed, **GBDT_KW).fit(XC[obs], y)
        out["corr_gbdt_cf"][te] = m.predict_proba(XC[te])[:, 1]
        w = 1.0 / e_tr[H[tr] == 1]
        m = LogisticRegression(max_iter=2000).fit(XP[obs], y, sample_weight=w)
        out["ipw"][te] = m.predict_proba(XP[te])[:, 1]
    for kname, v in out.items():
        df[kname] = v
    # pi_pre: popularity with a deterministic tie-break
    df["pop_score"] = df["pop"] + np.random.default_rng(seed + 1).uniform(0, 1e-6, n)
    df["fold"] = fold
    return df


def score_col(rule):
    return "pop_score" if rule == "pop" else rule


# --------------------------------------------------------------------------- #
# Estimators
# --------------------------------------------------------------------------- #
def top_mask(scores, q):
    k = max(1, int(round(q * len(scores))))
    idx = np.argpartition(-scores, k - 1)[:k]
    m = np.zeros(len(scores), bool)
    m[idx] = True
    return m


def gamma_band(p, G):
    """p: MAR predictions of unobserved units (vector); G: array of Gammas.
    Returns (sum_low, sum_high) over units, for each G."""
    G = np.asarray(G, float)[:, None]
    p = np.clip(p, 1e-9, 1 - 1e-9)[None, :]
    lo = p / (p + G * (1 - p))
    hi = G * p / (G * p + 1 - p)
    return lo.sum(1), hi.sum(1)


def value_block(sel, H, D, Dtrue, intest, e, eauth, mu_l, mu_g):
    n = sel.sum()
    obs = sel & (H == 1)
    unobs = sel & (H == 0)
    tsel = sel & intest
    eo = np.clip(e[obs], *CLIP_EVAL)
    ea = np.clip(eauth[obs], *CLIP_EVAL)
    Do = D[obs]
    es = np.clip(e[sel], *CLIP_EVAL)
    Hs, Ds = H[sel], np.nan_to_num(D[sel])
    r = dict(
        n_set=int(n), n_obs=int(obs.sum()), unobs_share=unobs.sum() / n,
        n_truth=int(tsel.sum()),
        truth=np.nanmean(Dtrue[tsel]) if tsel.any() else np.nan,
        naive=Do.mean() if obs.any() else np.nan,
        ipw=(Do / eo).sum() / (1 / eo).sum() if obs.any() else np.nan,
        ipw_auth=(Do / ea).sum() / (1 / ea).sum() if obs.any() else np.nan,
        aipw_logit=np.mean(mu_l[sel] + Hs / es * (Ds - mu_l[sel])),
        aipw_gbdt=np.mean(mu_g[sel] + Hs / es * (Ds - mu_g[sel])),
        impute=(Do.sum() + mu_l[unobs].sum()) / n,
        manski_lo=Do.sum() / n,
        manski_hi=(Do.sum() + unobs.sum()) / n,
    )
    return r


def compute_all(df, qs, gammas):
    H = df.H.values
    D = df.D_obs.values
    Dt = df.D_true.values
    it = df.in_test.values
    e, ea = df.e.values, df.e_auth.values
    ml, mg = df.mu_logit.values, df.mu_gbdt.values
    rows, curves, sets = [], [], {}
    for q in qs:
        for rule in ALL_RULES:
            sel = top_mask(df[score_col(rule)].values, q)
            sets[(rule, q)] = sel
            r = value_block(sel, H, D, Dt, it, e, ea, ml, mg)
            r.update(rule=rule, q=q)
            rows.append(r)
            obs_sum = np.nansum(D[sel & (H == 1)])
            lo, hi = gamma_band(ml[sel & (H == 0)], gammas)
            n = sel.sum()
            for G, l, h in zip(gammas, lo, hi):
                curves.append(dict(rule=rule, q=q, gamma=G,
                                   V_lo=(obs_sum + l) / n, V_hi=(obs_sum + h) / n))
    return pd.DataFrame(rows), pd.DataFrame(curves), sets


def auc_block(df, w_eval=True):
    out = []
    t = df[df.in_test]
    v = df[df.H == 1]
    wv = 1.0 / np.clip(v.e.values, *CLIP_EVAL)
    for rule in ALL_RULES:
        s = score_col(rule)
        out.append(dict(
            rule=rule,
            auc_oracle_randomtest=roc_auc_score(t.D_true, t[s]),
            auc_visible_unweighted=roc_auc_score(v.D_obs, v[s]),
            auc_visible_weighted=roc_auc_score(v.D_obs, v[s], sample_weight=wv),
        ))
    return pd.DataFrame(out)


# --------------------------------------------------------------------------- #
# Gamma summaries
# --------------------------------------------------------------------------- #
def gamma_cover(curve, truth, lo_ci=None, hi_ci=None):
    """Smallest Gamma whose band contains the truth point (and, if given, intersects
    the truth's 95% CI)."""
    c = curve.sort_values("gamma")
    pt = c[(c.V_lo <= truth) & (c.V_hi >= truth)]
    g_pt = pt.gamma.iloc[0] if len(pt) else np.inf
    g_ci = np.nan
    if lo_ci is not None:
        ci = c[(c.V_lo <= hi_ci) & (c.V_hi >= lo_ci)]
        g_ci = ci.gamma.iloc[0] if len(ci) else np.inf
    return g_pt, g_ci


def vov_gamma(curves, post, pre, q):
    a = curves[(curves.rule == post) & (curves.q == q)].sort_values("gamma").reset_index(drop=True)
    b = curves[(curves.rule == pre) & (curves.q == q)].sort_values("gamma").reset_index(drop=True)
    lo = a.V_lo - b.V_hi
    hi = a.V_hi - b.V_lo
    g = a.gamma
    centre = (a.V_lo.iloc[0] + a.V_hi.iloc[0]) / 2 - (b.V_lo.iloc[0] + b.V_hi.iloc[0]) / 2
    if centre > 0:
        hit = g[lo <= 0]
    else:
        hit = g[hi >= 0]
    g_star = hit.iloc[0] if len(hit) else np.inf
    return pd.DataFrame(dict(gamma=g, VoV_lo=lo, VoV_hi=hi)), centre, g_star


# --------------------------------------------------------------------------- #
# User-clustered bootstrap
# --------------------------------------------------------------------------- #
def bootstrap(df, qs, B, seed):
    rng = np.random.default_rng(seed)
    U = df.u.max() + 1
    I = df.i.max() + 1
    # rows are ordered user-major: row = u*I + i
    base = np.arange(I)
    val_rows, auc_rows = [], []
    for b in range(B):
        us = rng.integers(0, U, U)
        idx = (us[:, None] * I + base[None, :]).ravel()
        s = df.iloc[idx]
        H, D, Dt, it = s.H.values, s.D_obs.values, s.D_true.values, s.in_test.values
        e, ea, ml, mg = s.e.values, s.e_auth.values, s.mu_logit.values, s.mu_gbdt.values
        vals = {}
        for q in qs:
            for rule in ALL_RULES:
                sel = top_mask(s[score_col(rule)].values, q)
                r = value_block(sel, H, D, Dt, it, e, ea, ml, mg)
                r.update(rule=rule, q=q, b=b)
                val_rows.append(r)
        t = s[s.in_test]
        if t.D_true.nunique() == 2:
            ar = {r: roc_auc_score(t.D_true, t[score_col(r)]) for r in ALL_RULES}
            ar["b"] = b
            auc_rows.append(ar)
    return pd.DataFrame(val_rows), pd.DataFrame(auc_rows)


def summarise(x):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return dict(mean=np.nan, sd=np.nan, lo=np.nan, hi=np.nan)
    return dict(mean=x.mean(), sd=x.std(ddof=1), lo=np.percentile(x, 2.5), hi=np.percentile(x, 97.5))


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", default="results_coat")
    ap.add_argument("--threshold", type=float, default=4)
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--boot", type=int, default=500)
    ap.add_argument("--qs", type=float, nargs="+", default=[0.05, 0.10, 0.20])
    ap.add_argument("--q-main", type=float, default=0.10)
    args = ap.parse_args()
    t0 = time.time()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    gammas = np.unique(np.concatenate([np.exp(np.linspace(0, np.log(1000), 300)), [1e9]]))

    d = load_coat(args.data)
    df, X, xnames = build_pairs(d, args.threshold)
    df = cross_fit(df, X, args.folds, args.seed)

    # ---------------- diagnostics ----------------
    H = df.H.values
    w = 1 / np.clip(df.e.values[H == 1], *CLIP_EVAL)
    diag = dict(
        n_pairs=len(df), n_visible=int(H.sum()), visibility_rate=H.mean(),
        n_randomtest=int(df.in_test.sum()),
        overlap_visible_randomtest=int((df.in_test & (H == 1)).sum()),
        pos_rate_visible=float(np.nanmean(df.D_obs)),
        pos_rate_randomtest=float(np.nanmean(df.D_true)),
        e_sum=float(df.e.sum()), e_p5=float(np.percentile(df.e, 5)),
        e_p95=float(np.percentile(df.e, 95)), e_min=float(df.e.min()), e_max=float(df.e.max()),
        w_max_visible=float(w.max()), ESS_fraction_visible=float(w.sum() ** 2 / (w ** 2).sum() / len(w)),
        spearman_e_vs_author=float(pd.Series(df.e).corr(pd.Series(df.e_auth), method="spearman")),
        auc_propensity_oof=float(roc_auc_score(H, df.e)),
        auc_value_model_logit_oof=float(roc_auc_score(df.D_obs[H == 1], df.mu_logit[H == 1])),
        auc_value_model_gbdt_oof=float(roc_auc_score(df.D_obs[H == 1], df.mu_gbdt[H == 1])),
    )

    # ---------------- point estimates ----------------
    auc = auc_block(df)
    val, curves, _ = compute_all(df, args.qs, gammas)

    # ---------------- bootstrap ----------------
    bval, bauc = bootstrap(df, args.qs, args.boot, args.seed + 7)

    # value CIs
    est_cols = ["truth", "naive", "ipw", "ipw_auth", "aipw_logit", "aipw_gbdt", "impute"]
    ci_rows = []
    for (rule, q), g in bval.groupby(["rule", "q"]):
        r = dict(rule=rule, q=q)
        for c in est_cols:
            sm = summarise(g[c])
            r.update({f"{c}_sd": sm["sd"], f"{c}_lo": sm["lo"], f"{c}_hi": sm["hi"]})
        # bias of each estimator relative to truth, paired on replicates
        for c in ["naive", "ipw", "aipw_logit", "aipw_gbdt", "impute"]:
            sm = summarise(g[c] - g["truth"])
            r.update({f"bias_{c}_lo": sm["lo"], f"bias_{c}_hi": sm["hi"]})
        ci_rows.append(r)
    val = val.merge(pd.DataFrame(ci_rows), on=["rule", "q"])
    for c in ["naive", "ipw", "ipw_auth", "aipw_logit", "aipw_gbdt", "impute"]:
        val[f"bias_{c}"] = val[c] - val["truth"]
    for c in ["ipw", "ipw_auth", "aipw_logit", "aipw_gbdt", "impute"]:
        val[f"reduction_{c}"] = 1 - val[f"bias_{c}"].abs() / val["bias_naive"].abs()

    # AUC CIs and the paired ipw - corr_logit difference
    auc_ci = []
    for rname in ALL_RULES:
        sm = summarise(bauc[rname])
        auc_ci.append(dict(rule=rname, auc_oracle_sd=sm["sd"], auc_oracle_lo=sm["lo"], auc_oracle_hi=sm["hi"]))
    auc = auc.merge(pd.DataFrame(auc_ci), on="rule")
    diff = bauc["ipw"] - bauc["corr_logit"]
    d_pt = float(auc.set_index("rule").loc["ipw", "auc_oracle_randomtest"]
                 - auc.set_index("rule").loc["corr_logit", "auc_oracle_randomtest"])
    d_sm = summarise(diff)

    # VoV: each fitted rule vs pop
    vov_rows, vov_curves = [], []
    for q in args.qs:
        vq = val[val.q == q].set_index("rule")
        bq = bval[bval.q == q]
        for post in FITTED_RULES:
            r = dict(post=post, pre="pop", q=q)
            for c in ["truth", "naive", "ipw", "aipw_logit", "aipw_gbdt", "impute"]:
                r[c] = vq.loc[post, c] - vq.loc["pop", c]
                pa = bq[bq.rule == post].sort_values("b")[c].values
                pb = bq[bq.rule == "pop"].sort_values("b")[c].values
                sm = summarise(pa - pb)
                r[f"{c}_lo"], r[f"{c}_hi"] = sm["lo"], sm["hi"]
            r["manski_lo"] = vq.loc[post, "manski_lo"] - vq.loc["pop", "manski_hi"]
            r["manski_hi"] = vq.loc[post, "manski_hi"] - vq.loc["pop", "manski_lo"]
            vc, centre, gstar = vov_gamma(curves, post, "pop", q)
            r["gamma_star_signflip"] = gstar
            vc["post"], vc["q"] = post, q
            vov_curves.append(vc)
            vov_rows.append(r)
    vov = pd.DataFrame(vov_rows)
    vov_curves = pd.concat(vov_curves)

    # empirical Gamma per policy
    gc_rows = []
    for _, r in val.iterrows():
        c = curves[(curves.rule == r.rule) & (curves.q == r.q)]
        gpt, gci = gamma_cover(c, r.truth, r.truth_lo, r.truth_hi)
        gc_rows.append(dict(rule=r.rule, q=r.q, gamma_cover_point=gpt, gamma_cover_truthCI=gci))
    gcov = pd.DataFrame(gc_rows)
    val = val.merge(gcov, on=["rule", "q"])

    # ---------------- write ----------------
    val.to_csv(out / "value_by_rule.csv", index=False)
    auc.to_csv(out / "auc_by_rule.csv", index=False)
    vov.to_csv(out / "vov.csv", index=False)
    curves.to_csv(out / "gamma_curves_value.csv", index=False)
    vov_curves.to_csv(out / "gamma_curves_vov.csv", index=False)
    bval.to_csv(out / "bootstrap_value_replicates.csv", index=False)
    bauc.to_csv(out / "bootstrap_auc_replicates.csv", index=False)
    cfg = vars(args).copy()
    cfg.update(n_features=X.shape[1], feature_names=xnames, clip_eval=CLIP_EVAL,
               clip_fit=CLIP_FIT, gbdt=GBDT_KW, runtime_sec=round(time.time() - t0, 1))
    (out / "config.json").write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
    (out / "diagnostics.json").write_text(json.dumps(diag, indent=2), encoding="utf-8")

    # ---------------- report ----------------
    qm = args.q_main
    L = []
    L.append("COAT REAL-SELECTION VALIDATION — REPORT")
    L.append(f"threshold D = 1[rating >= {args.threshold}], folds = {args.folds}, seed = {args.seed}, "
             f"bootstrap B = {args.boot} (user-clustered), main q = {qm}")
    L.append("\n== Pre-registered criteria ==")
    L.append("C1 ranking insensitivity: 95% CI of AUC_oracle(ipw) - AUC_oracle(corr_logit) contains 0.")
    L.append("C2 value sensitivity: naive overestimates the true value of the selected set, and "
             "|bias(AIPW)| < |bias(naive)| (reported per rule at main q; directional, no threshold).")
    L.append("C3 empirical Gamma: smallest Gamma whose band covers the true value (point / truth-CI).")
    L.append("C4 sign agreement: sign(true VoV) == sign(model-based VoV) for each fitted rule vs pop.")
    L.append("\n== Diagnostics ==")
    for k, v in diag.items():
        L.append(f"  {k}: {v:.4f}" if isinstance(v, float) else f"  {k}: {v}")
    L.append("\n== AUC (oracle = random-exposure test set) ==")
    L.append(auc.round(4).to_string(index=False))
    c1 = d_sm["lo"] <= 0 <= d_sm["hi"]
    L.append(f"\nC1: AUC_oracle(ipw) - AUC_oracle(corr_logit) = {d_pt:+.4f}, "
             f"bootstrap sd {d_sm['sd']:.4f}, 95% CI [{d_sm['lo']:+.4f}, {d_sm['hi']:+.4f}] "
             f"-> {'MET' if c1 else 'NOT MET'}")
    L.append(f"\n== Value of the top-{qm:.0%} set (main q) ==")
    cols = ["rule", "unobs_share", "n_truth", "truth", "naive", "ipw", "ipw_auth", "aipw_logit",
            "aipw_gbdt", "impute", "manski_lo", "manski_hi"]
    L.append(val[val.q == qm][cols].round(4).to_string(index=False))
    L.append("\nC2 per rule (main q): bias = estimate - truth; reduction = 1 - |bias|/|naive bias|")
    for _, r in val[val.q == qm].iterrows():
        ok = (r.bias_naive > 0) and (abs(r.bias_aipw_logit) < abs(r.bias_naive))
        L.append(f"  {r.rule:13s} naive bias {r.bias_naive:+.4f} "
                 f"[{r.bias_naive_lo:+.4f},{r.bias_naive_hi:+.4f}] | "
                 f"IPW red. {r.reduction_ipw:+.2f} | AIPW-logit red. {r.reduction_aipw_logit:+.2f} | "
                 f"AIPW-gbdt red. {r.reduction_aipw_gbdt:+.2f} -> {'MET' if ok else 'NOT MET'}")
    L.append("\nC3 empirical Gamma (main q):")
    for _, r in val[val.q == qm].iterrows():
        L.append(f"  {r.rule:13s} Gamma_cover(point) = {r.gamma_cover_point:.3g}, "
                 f"Gamma_cover(truth CI) = {r.gamma_cover_truthCI:.3g}")
    L.append(f"\n== VoV = V(fitted rule) - V(pop), top-{qm:.0%} ==")
    vcols = ["post", "truth", "truth_lo", "truth_hi", "naive", "ipw", "aipw_logit", "aipw_gbdt",
             "impute", "manski_lo", "manski_hi", "gamma_star_signflip"]
    L.append(vov[vov.q == qm][vcols].round(4).to_string(index=False))
    L.append("\nC4 sign agreement (main q, AIPW-logit vs truth):")
    for _, r in vov[vov.q == qm].iterrows():
        L.append(f"  {r.post:13s} sign(truth)={np.sign(r.truth):+.0f}, sign(AIPW)={np.sign(r.aipw_logit):+.0f} "
                 f"-> {'MET' if np.sign(r.truth) == np.sign(r.aipw_logit) else 'NOT MET'}")
    L.append(f"\nruntime: {time.time() - t0:.1f} s")
    rep = "\n".join(L)
    (out / "report.txt").write_text(rep, encoding="utf-8")
    print(rep)

    # ---------------- figure ----------------
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
        ax = axes[0]
        for rule, col in [(POST_MAIN, "C0"), ("pop", "C3")]:
            c = curves[(curves.rule == rule) & (curves.q == qm) & (curves.gamma < 1e8)]
            ax.fill_between(c.gamma, c.V_lo, c.V_hi, alpha=0.25, color=col, label=f"{rule}: Gamma band")
            r = val[(val.rule == rule) & (val.q == qm)].iloc[0]
            ax.axhspan(r.truth_lo, r.truth_hi, color=col, alpha=0.12)
            ax.axhline(r.truth, color=col, ls="--", lw=1.2, label=f"{rule}: truth (random test)")
            ax.plot([1], [r.naive], marker="x", color=col, ls="none")
        ax.set_xscale("log"); ax.set_xlabel("Gamma"); ax.set_ylabel(f"value of top-{qm:.0%} set")
        ax.set_title("Value: Gamma band vs truth"); ax.legend(fontsize=7)
        ax = axes[1]
        c = vov_curves[(vov_curves.post == POST_MAIN) & (vov_curves.q == qm) & (vov_curves.gamma < 1e8)]
        ax.fill_between(c.gamma, c.VoV_lo, c.VoV_hi, alpha=0.3, color="C0", label="VoV Gamma band")
        r = vov[(vov.post == POST_MAIN) & (vov.q == qm)].iloc[0]
        ax.axhspan(r.truth_lo, r.truth_hi, color="k", alpha=0.1)
        ax.axhline(r.truth, color="k", ls="--", lw=1.2, label="true VoV (random test)")
        ax.axhline(0, color="grey", lw=0.8)
        if np.isfinite(r.gamma_star_signflip):
            ax.axvline(r.gamma_star_signflip, color="C3", ls=":", label=f"Gamma* = {r.gamma_star_signflip:.2f}")
        ax.set_xscale("log"); ax.set_xlabel("Gamma"); ax.set_ylabel("VoV")
        ax.set_title(f"VoV({POST_MAIN} - pop)"); ax.legend(fontsize=7)
        fig.tight_layout()
        fig.savefig(out / "gamma_plot.png", dpi=200)
    except Exception as ex:  # plotting is optional
        print("plot skipped:", ex)


if __name__ == "__main__":
    main()
