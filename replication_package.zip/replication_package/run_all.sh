#!/usr/bin/env bash
# Usage: bash run_all.sh <PLATFORM_DATA_DIR> <COAT_DIR> <KUAIRAND_DATA_DIR> [OUT_DIR] [--quick]
# --quick: fewer bootstrap replicates / seeds (smoke test only)
set -e
PLAT=$(realpath "$1"); COAT=$(realpath "$2"); KR=$(realpath "$3"); OUT=$(realpath -m "${4:-results}")
QUICK=""; [[ "$5" == "--quick" ]] && QUICK=1
mkdir -p "$OUT"; ROOT=$(cd "$(dirname "$0")" && pwd)
B=1000; NB=500; SEEDS=20; [[ -n "$QUICK" ]] && B=50 && NB=30 && SEEDS=2
cd "$ROOT/platform"
python step1_main.py      --data "$PLAT" --mode final --out "$OUT/platform_step1" --B $B
python step2_selection.py --data "$PLAT" --mode final --step1 "$OUT/platform_step1" --out "$OUT/platform_step2"
python step3_value.py     --data "$PLAT" --mode final --step1 "$OUT/platform_step1" --out "$OUT/platform_step3" --nboot $B
python step4_gamma.py     --data "$PLAT" --step1 "$OUT/platform_step1" --out "$OUT/platform_step4" --nboot $NB
python step5_signal.py    --data "$PLAT" --out "$OUT/platform_step5"
cd "$ROOT/benchmarks/coat"
python coat_experiment.py --data "$COAT" --out "$OUT/coat_t4" --boot $NB
python coat_experiment.py --data "$COAT" --threshold 3 --out "$OUT/coat_t3" --boot $NB
cd "$ROOT/benchmarks/kuairand"
python kuairand_experiment.py --data "$KR" --out "$OUT/kuairand_click" --nboot $NB
python kuairand_experiment.py --data "$KR" --outcome long_view --out "$OUT/kuairand_longview" --nboot $NB
cd "$ROOT/synthetic"
python synthetic_experiment.py --out "$OUT/synthetic" --seeds $SEEDS
cd "$ROOT"
python tools/make_figure3.py --results "$OUT"
python tools/make_figures_svg.py --results "$OUT" --out "$OUT/figures"
echo "All done. Reports: $OUT/*/report.txt"
