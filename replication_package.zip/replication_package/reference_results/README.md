# Reference results

Reports produced by the authors' full run (`run_all`, final mode), with the same sub-directory names as
`results/`: platform_step1 ... platform_step5, coat_t4, coat_t3, kuairand_click, kuairand_longview, synthetic.
The figures of the paper are included as produced: `platform_step4/gamma_plot_platform.png` (Figure 1),
`figure3_gamma_anchors.png` (Figure 3), and the benchmark Γ plots for Coat and KuaiRand.
Compare your own `results/*/report.txt` with these files. Differences in the fourth decimal can arise from
library versions.
