# -*- coding: utf-8 -*-
"""
step4_gamma.py — Γ-sensitivity analysis linking the MAR estimate to the Manski bounds (Section 5.5, Table 8, Figure 1).

Usage (after step 1, final mode):
  python step4_gamma.py --data "C:\\...\\DATA" --step1 results_step1_final --out results_step4

Sensitivity model (as in the benchmark scripts): for each unobserved unit in the selected set with MAR prediction p = mu(x),
  P(D=1 | x, H=0) ∈ [ p/(p+Γ(1−p)),  Γp/(Γp+1−p) ]
Gamma = 1 gives regression imputation (MAR); Gamma -> infinity gives the Manski bounds. Observed units contribute their D.
  V-(pi, Gamma), V+(pi, Gamma)   interval for the value of the selected set
  VoV⁻(Γ) = V⁻(gbdt) − V⁺(raw_S),  VoV⁺(Γ) = V⁺(gbdt) − V⁻(raw_S)
  Gamma* = first Gamma at which VoV-(Gamma) <= 0 (breakdown value)
Value models mu:
  gbdt      = predictions of corr_gbdt (exo specification); main
  logistic  = predictions of corr_logit (exo specification); conservative
Calibration:
  (a) empirical Gamma on Coat (user self-selection) and KuaiRand (recommender exposure), shown as reference bands;
  (b) covariate benchmark: factor by which omitting one observed covariate changes the predicted outcome odds
      of the unobserved units in the audited set.
Uncertainty: job-clustered bootstrap on the primary split (500 replicates by default) for Gamma*.
Runtime: about 3-8 minutes.
"""
import argparse
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression

import common
from common import load_raw, build_panel, job_split, Prep, X_COLS
from rules import topk_order, boot_indices

COAT_GAMMA = {"point_min": 1.18, "point_max": 1.78, "ci_min": 1.00, "ci_max": 1.41}   # Coat, rating >= 4 (Table 10)
KUAIRAND_GAMMA = {"min": 3.47, "max": 5.62}   # KuaiRand, click and long view, top-5% (Section 6.3)
GRID = np.unique(np.concatenate([np.exp(np.linspace(0, np.log(50), 400)), [1e9]]))
RULES4 = ["raw_S", "corr_XZ", "corr_logit", "corr_gbdt", "ipw"]
lines = []


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s, flush=True)
    lines.append(s)


def band(sel, H, D, mu, G=GRID):
    """Return the arrays (V-(Gamma), V+(Gamma)) over G. sel may contain repeated indices."""
    h = H[sel] == 1
    obs_sum = np.nan_to_num(D[sel])[h].sum()
    p = np.clip(mu[sel][~h], 1e-9, 1 - 1e-9)[None, :]
    g = np.asarray(G)[:, None]
    lo = (p / (p + g * (1 - p))).sum(1)
    hi = (g * p / (g * p + 1 - p)).sum(1)
    n = len(sel)
    return (obs_sum + lo) / n, (obs_sum + hi) / n


def gamma_star(vlo_post, vhi_pre, G=GRID):
    d = vlo_post - vhi_pre
    if d[0] <= 0:
        return 1.0 if d[0] == 0 else np.nan        # VoV not positive even under MAR
    hit = np.flatnonzero(d <= 0)
    return float(G[hit[0]]) if len(hit) else np.inf


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--step1", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--Bs", type=int, nargs="+", default=[100, 500, 1000])
    ap.add_argument("--B_main", type=int, default=500)
    ap.add_argument("--nboot", type=int, default=500)
    ap.add_argument("--seeds", type=int, nargs="+", default=common.CONFIG["seeds_main"])
    args = ap.parse_args()
    t0 = time.time()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    common.CONFIG["mode"] = "final"
    df = build_panel(load_raw(args.data))
    s1 = Path(args.step1)
    primary = args.seeds[0]
    log(f"STEP4  n={len(df):,}  seeds={args.seeds}  B={args.Bs}  nboot={args.nboot}")
    log(f"Reference: empirical Gamma on Coat [{COAT_GAMMA['point_min']}, {COAT_GAMMA['point_max']}]"
        f" (truth CI basis [{COAT_GAMMA['ci_min']}, {COAT_GAMMA['ci_max']}]); KuaiRand [{KUAIRAND_GAMMA['min']}, {KUAIRAND_GAMMA['max']}]")

    star_rows, curve_rows = [], []
    prim = None
    for seed in args.seeds:
        tr = job_split(df, seed)
        te = ~tr
        prep = Prep().fit(df[tr])
        t_tr, t_te = prep.transform(df[tr]), prep.transform(df[te])
        H, D = t_te["H"], t_te["D"]
        z = np.load(s1 / f"scores_exo_seed{seed}.npz")
        if not np.array_equal(z["test_index"], np.flatnonzero(te)):
            raise RuntimeError("step-1 scores do not match this split: use the final-mode step-1 directory")
        MU = {"gbdt": z["corr_gbdt"], "logistic": z["corr_logit"]}
        ranks = {}
        for r in RULES4:
            o = topk_order(z[r])
            rk = np.empty(len(o), int)
            rk[o] = np.arange(len(o))
            ranks[r] = rk
        for B in args.Bs:
            sels = {r: np.argpartition(ranks[r], B - 1)[:B] for r in RULES4}
            for mname, mu in MU.items():
                bands = {r: band(sels[r], H, D, mu) for r in RULES4}
                for post in ["corr_gbdt", "corr_logit", "corr_XZ", "ipw"]:
                    vlo, vhi = bands[post][0], bands[post][1]
                    plo, phi = bands["raw_S"]
                    star_rows.append(dict(seed=seed, B=B, mu=mname, post=post,
                                          VoV_MAR=vlo[0] - plo[0], gamma_star=gamma_star(vlo, phi),
                                          VoV_manski_lo=vlo[-1] - phi[-1], VoV_manski_hi=vhi[-1] - plo[-1]))
                if seed == primary and B == args.B_main:
                    for r in RULES4:
                        for g, l, h in zip(GRID, *bands[r]):
                            curve_rows.append(dict(mu=mname, rule=r, gamma=g, V_lo=l, V_hi=h))
        if seed == primary:
            prim = dict(H=H, D=D, MU=MU, ranks=ranks, jobs=df.jd_no.values[te], t_tr=t_tr, t_te=t_te, te=te)
        log(f"  seed {seed} done [{time.time() - t0:.0f}s]")

    st = pd.DataFrame(star_rows)
    st.to_csv(out / "gamma_star_by_seed.csv", index=False)
    cv = pd.DataFrame(curve_rows)
    cv.to_csv(out / "gamma_curves_primary.csv", index=False)

    log("\n[Gamma*] breakdown value of VoV = V(post) - V(raw_S): five-split mean / min / max; VoV_MAR at Gamma = 1 (imputation)")
    summ = st.groupby(["mu", "B", "post"]).agg(VoV_MAR=("VoV_MAR", "mean"), gamma_star_mean=("gamma_star", "mean"),
                                               gamma_star_min=("gamma_star", "min"), gamma_star_max=("gamma_star", "max"),
                                               manski_lo=("VoV_manski_lo", "mean"), manski_hi=("VoV_manski_hi", "mean"))
    log(summ.round(3).to_string())

    # ---- job-clustered bootstrap of Gamma* on the primary split (corr_gbdt vs raw_S, B_main)
    P = prim
    n = len(P["H"])
    log(f"\n[Gamma* job-clustered bootstrap] primary split seed {primary}, B={args.B_main}, {args.nboot} replicates")
    for mname, mu in P["MU"].items():
        gs = []
        for idx in boot_indices(n, args.nboot, 41, groups=P["jobs"]):
            sp = idx[np.argpartition(P["ranks"]["corr_gbdt"][idx], args.B_main - 1)[:args.B_main]]
            sr = idx[np.argpartition(P["ranks"]["raw_S"][idx], args.B_main - 1)[:args.B_main]]
            vlo, _ = band(sp, P["H"], P["D"], mu)
            _, phi = band(sr, P["H"], P["D"], mu)
            gs.append(gamma_star(vlo, phi))
        gs = np.array(gs, float)
        fin = gs[np.isfinite(gs)]
        log(f"  mu={mname:8s} Gamma* median {np.nanmedian(gs):.3f}, 2.5%-97.5% [{np.nanpercentile(gs, 2.5):.3f}, "
            f"{np.nanpercentile(gs, 97.5):.3f}]; share below the Coat maximum {COAT_GAMMA['point_max']}: "
            f"{np.mean(gs < COAT_GAMMA['point_max']):.3f}; share with VoV <= 0 under MAR: {np.mean(np.isnan(gs)):.3f}")

    # ---- covariate benchmark (primary split, logistic value model)
    log("\n[Covariate benchmark] odds-ratio change for unobserved units in the corr_gbdt set when one column is omitted (median / 90th pct)")
    t_tr, t_te = P["t_tr"], P["t_te"]
    obs = t_tr["H"] == 1
    y = t_tr["D"][obs].astype(int)
    F_tr = np.column_stack([t_tr["X"], t_tr["S"], t_tr["ind_s"], t_tr["Zexo"]])
    F_te = np.column_stack([t_te["X"], t_te["S"], t_te["ind_s"], t_te["Zexo"]])
    names = X_COLS + ["S", "ind_s", "Zexo"]
    full = LogisticRegression(max_iter=2000).fit(F_tr[obs], y)
    sp = np.argpartition(P["ranks"]["corr_gbdt"], args.B_main - 1)[:args.B_main]
    sp = sp[P["H"][sp] == 0]
    lf = full.decision_function(F_te[sp])
    bench = []
    for j, nm in enumerate(names):
        keep = [k for k in range(F_tr.shape[1]) if k != j]
        m = LogisticRegression(max_iter=2000).fit(F_tr[obs][:, keep], y)
        orr = np.exp(np.abs(lf - m.decision_function(F_te[sp][:, keep])))
        bench.append(dict(covariate=nm, OR_median=np.median(orr), OR_p90=np.percentile(orr, 90)))
    bench = pd.DataFrame(bench).sort_values("OR_p90", ascending=False)
    bench.to_csv(out / "covariate_benchmark.csv", index=False)
    log(bench.round(3).to_string(index=False))

    # ---- figure
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.3))
        for ax, mname in zip(axes, ["gbdt", "logistic"]):
            a = cv[(cv.mu == mname) & (cv.rule == "corr_gbdt") & (cv.gamma < 1e8)].sort_values("gamma")
            b = cv[(cv.mu == mname) & (cv.rule == "raw_S") & (cv.gamma < 1e8)].sort_values("gamma")
            lo = a.V_lo.values - b.V_hi.values
            hi = a.V_hi.values - b.V_lo.values
            ax.fill_between(a.gamma, lo, hi, color="C0", alpha=0.3, label="VoV band")
            ax.axvspan(COAT_GAMMA["point_min"], COAT_GAMMA["point_max"], color="C2", alpha=0.15,
                       label="Coat empirical Γ (self-selection)")
            ax.axvspan(KUAIRAND_GAMMA["min"], KUAIRAND_GAMMA["max"], color="C1", alpha=0.15,
                       label="KuaiRand empirical Γ (exposure)")
            ax.axhline(0, color="grey", lw=0.8)
            gsr = st[(st.seed == primary) & (st.B == args.B_main) & (st.mu == mname) & (st.post == "corr_gbdt")]
            g0 = gsr.gamma_star.iloc[0]
            if np.isfinite(g0):
                ax.axvline(g0, color="C3", ls=":", label=f"Γ* = {g0:.2f}")
            ax.set_xscale("log")
            ax.set_xlabel("Γ")
            ax.set_ylabel(f"VoV (top-{args.B_main})")
            ax.set_title(f"VoV(corr_gbdt − raw_S), value model: {mname}")
            ax.legend(fontsize=7)
        fig.tight_layout()
        fig.savefig(out / "gamma_plot_platform.png", dpi=200)
    except Exception as ex:
        log("figure skipped:", ex)

    log(f"\nTotal runtime {time.time() - t0:.0f} s")
    (out / "report.txt").write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    main()
