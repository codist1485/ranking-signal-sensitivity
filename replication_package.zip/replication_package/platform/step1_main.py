# -*- coding: utf-8 -*-
"""
step1_main.py — ranking on the visible subset (Sections 5.1–5.2, Tables 3–4; Appendix A.1, A.3).

Usage:
  python step1_main.py --data <PLATFORM_DIR> --mode final --out results/platform_step1
  python step1_main.py --data <PLATFORM_DIR> --mode record --out results/platform_step1_record   (Appendix A.3)

  final : distinct candidate-job pairs; main specification "exo", competition specification "Z" as sensitivity
  record: raw interaction records (repeats included), raw salary/age codes

Outputs (--out): report.txt, auc_by_seed.csv, table3_<spec>.csv, decomposition_<spec>.csv, topk_<spec>.csv,
  subgroup_<spec>.csv, coverage.json, and scores_<spec>_seed<k>.npz (test-set scores reused by steps 2-4).
Runtime: about 10-20 minutes.
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA

import common
from common import load_raw, build_panel, job_split, Prep
from rules import (RULES, fit_rules, score_rules, auc_fast, delong_test, boot_indices,
                   topk_order, TIE_SEED)

lines = []


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s, flush=True)
    lines.append(s)


def pct(x):
    return np.percentile(x, [2.5, 97.5])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--mode", choices=["record", "final"], required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--specs", nargs="+", default=None)
    ap.add_argument("--B", type=int, default=1000)
    ap.add_argument("--seeds", type=int, nargs="+", default=common.CONFIG["seeds_main"])
    args = ap.parse_args()
    specs = args.specs or ["exo", "Z"]
    t0 = time.time()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    common.CONFIG["mode"] = args.mode

    raw = load_raw(args.data)
    df = build_panel(raw)
    log(f"STEP1  mode={args.mode}  unit={'record' if args.mode == 'record' else 'pair'}  n={len(df):,}  "
        f"H=1 {int(df.H.sum()):,}  specs={specs}  seeds={args.seeds}  B={args.B}")
    primary = args.seeds[0]

    auc_rows, topk_rows, sub_rows = [], [], []
    prim = {}
    for seed in args.seeds:
        tr = job_split(df, seed)
        te = ~tr
        prep = Prep().fit(df[tr])
        t_tr, t_te = prep.transform(df[tr]), prep.transform(df[te])
        h1 = t_te["H"] == 1
        y = t_te["D"][h1].astype(int)
        base = y.mean()
        # subgroups: quartiles of the first principal component of X on the test H=1 pairs
        pc = PCA(n_components=1).fit_transform(t_te["X"][h1])[:, 0]
        grp = pd.qcut(pd.Series(pc).rank(method="first"), 4, labels=False).values
        log(f"  seed {seed}: train {int(tr.sum()):,}  test {int(te.sum()):,}  test H=1 {int(h1.sum()):,}  "
            f"base {base:.4f}  [{time.time() - t0:.0f}s]")
        for spec in specs:
            m = fit_rules(t_tr, spec, seed)
            s = score_rules(m, t_te, spec)
            np.savez_compressed(out / f"scores_{spec}_seed{seed}.npz",
                                test_index=np.flatnonzero(te), **{k: v for k, v in s.items()})
            for r in RULES:
                sc = s[r][h1]
                auc_rows.append(dict(spec=spec, seed=seed, rule=r, auc=auc_fast(y, sc)))
                order = topk_order(sc)
                row = dict(spec=spec, seed=seed, rule=r, base=base)
                for k in (100, 500, 1000):
                    row[f"top{k}"] = y[order[:k]].mean()
                topk_rows.append(row)
                for g in range(4):
                    gm = grp == g
                    sub_rows.append(dict(spec=spec, seed=seed, rule=r, group=g,
                                         r_pb=np.corrcoef(sc[gm], y[gm])[0, 1] if sc[gm].std() > 0 else np.nan))
            if seed == primary:
                prim[spec] = dict(y=y, s={r: s[r][h1] for r in RULES},
                                  jobs=df.jd_no.values[te][h1], ind_s=t_te["ind_s"][h1],
                                  S_raw=df.S_raw.values[te][h1], s_fill=prep.s_fill)

    auc = pd.DataFrame(auc_rows)
    auc.to_csv(out / "auc_by_seed.csv", index=False)
    topk = pd.DataFrame(topk_rows)
    sub = pd.DataFrame(sub_rows)

    cov_info = {}
    for spec in specs:
        P = prim[spec]
        y, S, jobs = P["y"], P["s"], P["jobs"]
        n = len(y)
        log(f"\n================ specification {spec} ================")
        # ---- Table 3
        a = auc[auc.spec == spec].groupby("rule").auc.agg(["mean", "std"]).reindex(RULES)
        pa = {r: auc_fast(y, S[r]) for r in RULES}
        bt = {r: [] for r in RULES}
        bd = {r: [] for r in RULES}
        for idx in boot_indices(n, args.B, 2026):
            yy = y[idx]
            vals = {r: auc_fast(yy, S[r][idx]) for r in RULES}
            for r in RULES:
                bt[r].append(vals[r])
                bd[r].append(vals[r] - vals["raw_S"])
        ct = {r: [] for r in RULES}
        cd = {r: [] for r in RULES}
        for idx in boot_indices(n, args.B, 2027, groups=jobs):
            yy = y[idx]
            vals = {r: auc_fast(yy, S[r][idx]) for r in RULES}
            for r in RULES:
                ct[r].append(vals[r])
                cd[r].append(vals[r] - vals["raw_S"])
        t3 = []
        for r in RULES:
            dl = delong_test(y, S[r], S["raw_S"]) if r != "raw_S" else {}
            lo, hi = pct(bt[r])
            clo, chi = pct(ct[r])
            dlo, dhi = pct(bd[r]) if r != "raw_S" else (np.nan, np.nan)
            cdlo, cdhi = pct(cd[r]) if r != "raw_S" else (np.nan, np.nan)
            t3.append(dict(rule=r, auc_mean=a.loc[r, "mean"], auc_sd=a.loc[r, "std"], auc_primary=pa[r],
                           ci_lo=lo, ci_hi=hi, ci_cluster_lo=clo, ci_cluster_hi=chi,
                           diff_lo=dlo, diff_hi=dhi, diff_cluster_lo=cdlo, diff_cluster_hi=cdhi,
                           delong_z=dl.get("z", np.nan), delong_p=dl.get("p", np.nan)))
        t3 = pd.DataFrame(t3)
        t3.to_csv(out / f"table3_{spec}.csv", index=False)
        log("\n[Table 3] AUC: five-split mean/sd; primary-split point estimate, pair and job-clustered bootstrap CIs; DeLong vs raw_S")
        log(t3[["rule", "auc_mean", "auc_sd", "auc_primary", "ci_lo", "ci_hi", "ci_cluster_lo",
                "ci_cluster_hi", "delong_z"]].round(4).to_string(index=False))
        log("\n[AUC difference from raw_S] pair and job-clustered bootstrap CIs")
        log(t3[["rule", "diff_lo", "diff_hi", "diff_cluster_lo", "diff_cluster_hi"]].round(4).to_string(index=False))

        # ---- decomposition (Section 5.2)
        pairs = [("corr_S_only", "raw_S"), ("corr_XZ", "raw_S"), ("corr_logit", "corr_XZ"),
                 ("corr_gbdt", "corr_logit"), ("ipw", "corr_logit")]
        dec = []
        for a_, b_ in pairs:
            dl = delong_test(y, S[a_], S[b_])
            per = auc[(auc.spec == spec)].pivot(index="seed", columns="rule", values="auc")
            dd = per[a_] - per[b_]
            dec.append(dict(comparison=f"{a_} vs {b_}", diff_primary=dl["diff"], delong_z=dl["z"],
                            delong_p=dl["p"], diff_mean_5split=dd.mean(), diff_sd_5split=dd.std()))
        dec = pd.DataFrame(dec)
        dec.to_csv(out / f"decomposition_{spec}.csv", index=False)
        log("\n[Decomposition] primary-split DeLong (positive favours the first rule) and five-split paired differences")
        log(dec.round(4).to_string(index=False))

        # ---- top-k (Table 3, right part)
        tk = topk[topk.spec == spec].copy()
        rawk = tk[tk.rule == "raw_S"].set_index("seed")
        for k in (100, 500, 1000):
            tk[f"lift{k}"] = tk[f"top{k}"] / tk["base"]
            tk[f"RG{k}"] = (tk[f"top{k}"] - tk.seed.map(rawk[f"top{k}"])) / tk.seed.map(rawk[f"top{k}"])
        t4 = tk.groupby("rule")[[c for c in tk.columns if c.startswith(("top", "lift", "RG"))]].mean().reindex(RULES)
        t4.to_csv(out / f"topk_{spec}.csv")
        log("\n[Top-k] mean D, lift and relative gain over raw_S (five-split means; ties broken with seed 1206)")
        log(t4.round(4).to_string())

        # ---- subgroups (Table 4)
        sp = sub[(sub.spec == spec) & (sub.seed == primary)].pivot(index="rule", columns="group", values="r_pb").reindex(RULES)
        sp["range"] = sp.max(axis=1) - sp.min(axis=1)
        rng5 = sub[sub.spec == spec].groupby(["rule", "seed"]).r_pb.agg(lambda v: v.max() - v.min())
        sp["range_mean_5split"] = rng5.groupby("rule").mean()
        sp["range_sd_5split"] = rng5.groupby("rule").std()
        sp.to_csv(out / f"subgroup_{spec}.csv")
        log("\n[Table 4] within-group point-biserial correlation (primary split), range, five-split range mean/sd")
        log(sp.round(4).to_string())

        # ---- coverage ceiling and coverage-adjusted AUC (Proposition 1)
        cov = P["ind_s"] == 1
        cpos, cneg = cov[y == 1].mean(), cov[y == 0].mean()
        q = 1 - (1 - cpos) * (1 - cneg)
        a_raw = pa["raw_S"]
        cs = [auc_fast(y[idx][cov[idx]], S["raw_S"][idx][cov[idx]])
              for idx in boot_indices(n, args.B, 2028, groups=jobs)]
        cov_info[spec] = dict(n_test_h1=int(n), covered=int(cov.sum()), coverage=float(cov.mean()),
                              c_pos=float(cpos), c_neg=float(cneg), q=float(q), ceiling=float(q / 2),
                              auc_raw_S=float(a_raw), departure=float(a_raw - 0.5),
                              coverage_adjusted_auc=float(0.5 + (a_raw - 0.5) / q),
                              covered_subset_auc=float(auc_fast(y[cov], S["raw_S"][cov])),
                              covered_subset_ci_cluster=[float(v) for v in np.nanpercentile(cs, [2.5, 97.5])])
        log("\n[Coverage ceiling] ", json.dumps(cov_info[spec]))
        # sensitivity of raw_S to the constant used for uncovered pairs (diagnostic)
        fills = {"training mean (used)": P["s_fill"], "0 (bottom)": 0.0, "1.01 (top)": 1.01}
        msg = []
        for k, f in fills.items():
            sr = np.where(np.isnan(P["S_raw"]), f, P["S_raw"])
            od = topk_order(sr)
            msg.append(f"{k}: AUC {auc_fast(y, sr):.4f}, top100 {y[od[:100]].mean():.4f}, "
                       f"top500 {y[od[:500]].mean():.4f}, top1000 {y[od[:1000]].mean():.4f}")
        log("[raw_S fill-constant diagnostic] " + " | ".join(msg))

    (out / "coverage.json").write_text(json.dumps(cov_info, indent=2, ensure_ascii=False), encoding="utf-8")
    log(f"\nTotal runtime {time.time() - t0:.0f} s")
    (out / "report.txt").write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    main()
