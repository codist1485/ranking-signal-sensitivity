# -*- coding: utf-8 -*-
"""
common.py — loading, cleaning, variable construction and job-grouped splitting for the platform data.

Every analysis step (step1 ... step5) obtains its data from this module, so that all variables have a
single definition. The implementation follows Section 4.1 of the paper; all implementation choices that
the text summarizes are collected in CONFIG below.

Dependencies: numpy, pandas, scikit-learn
"""
from pathlib import Path
import re
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA

# --------------------------------------------------------------------------- #
# Implementation choices
# --------------------------------------------------------------------------- #
CONFIG = dict(
    # Education label -> ordinal code (cur_degree_id, min_edu_level); labels are the Chinese strings in the data, unlisted labels -> missing.
    edu_map={
        "初中": 1, "初中及以下": 1, "中技": 2, "中专": 2, "中专/中技": 2, "高中": 2,   # junior/senior secondary
        "大专": 3, "本科": 4, "硕士": 5, "MBA": 5, "EMBA": 5, "博士": 6,               # college, bachelor, master, PhD
    },
    # min_years band code -> midpoint in years; unlisted codes are treated as missing.
    # 399 / 599 mean "3+ / 5+ years" and, like 1099 (10+ years), take the lower bound.
    years_mid={103: 2.0, 305: 4.0, 510: 7.5, 1099: 10.0, -1: 0.0, 0: 0.0, 1: 1.0, 399: 3.0, 599: 5.0},
    # Years of experience = ref_year - start_work_date (job postings date from 2019).
    ref_year=2019,
    # Sentinel headcount codes: set to missing only inside Z_exo; X keeps the raw coding.
    require_sentinels=(999, 896),
    frac_train=0.8,
    # mode = "final": analysis reported in the paper (desired salary as log band midpoint, "negotiable" -> missing;
    #                 ages below 16 -> missing; unit = distinct candidate-job pair).  mode = "record": raw codes, raw ages, record-level unit (Appendix A.3).
    mode="final",
    age_min_valid=16,
    # Unit of analysis: "pair" = distinct (user_id, jd_no), flags collapsed by maximum (final mode);
    #                   "row"  = raw action records including repeats (record mode).
    unit=None,      # None: follow mode (final -> pair, record -> row)
    seeds_main=[42, 123, 2024, 7, 999],
)

# Desired-salary code -> (lower, upper) CNY per month; open bands take the lower bound; "0" (negotiable) -> missing
SALARY_TABLE = {
    "1000": (0, 1000), "100002000": (1000, 2000), "200104000": (2001, 4000),
    "400106000": (4001, 6000), "600108000": (6001, 8000), "800110000": (8001, 10000),
    "1000115000": (10001, 15000), "1500125000": (15001, 25000), "2500135000": (25001, 35000),
    "2500199999": (25001, 25001), "3500150000": (35001, 50000), "5000170000": (50001, 70000),
    "70001100000": (70001, 100000), "100001150000": (100001, 150000),
}


def salary_log_mid(s):
    def f(x):
        if not isinstance(x, str) or x not in SALARY_TABLE:
            return np.nan
        lo, hi = SALARY_TABLE[x]
        return np.log1p((lo + hi) / 2)
    return s.astype(str).str.lstrip("0").replace("", "0").map(f)


X_COLS = ["u_edu", "u_age", "u_exp_years", "u_desire_salary_code", "u_log_resume_len",
          "u_n_exp_segments", "j_min_edu", "j_log_min_salary", "j_log_max_salary",
          "j_years_mid", "j_require_nums", "j_is_travel", "j_log_jd_len", "edu_gap"]
ZEXO_INPUT = ["zx_require_log", "j_log_min_salary", "j_log_max_salary", "j_min_edu", "j_log_jd_len"]


# --------------------------------------------------------------------------- #
# Loading and cleaning (four deterministic steps)
# --------------------------------------------------------------------------- #
def _read(p):
    for enc in ("utf-8", "utf-8-sig", "gb18030"):
        try:
            return pd.read_csv(p, dtype=str, keep_default_na=False, encoding=enc)
        except UnicodeDecodeError:
            continue
    raise RuntimeError(f"cannot read {p}")


def _clean(df):
    df = df.copy()
    df.columns = [re.sub(r"\s+", "", c) for c in df.columns]          # (i) strip whitespace/newlines from names
    for c in df.columns:
        df[c] = df[c].astype(str).str.strip()                          # (ii) trim strings
        df.loc[df[c].isin(["\\N", "nan", "NaN", ""]), c] = np.nan      # (iii) \N → NaN
    if "company_name" in df.columns:
        df["company_name"] = ""                                        # (iv)
    return df


def load_raw(data_dir):
    d = Path(data_dir)
    raw = {k: _clean(_read(d / f"{k}.csv")) for k in ["user", "job", "action", "rank_job", "rank_resume"]}
    return raw


def _num(s):
    return pd.to_numeric(s, errors="coerce")


def _len(s):
    return s.fillna("").astype(str).str.len()


# --------------------------------------------------------------------------- #
# Variable construction
# --------------------------------------------------------------------------- #
def build_panel(raw, cfg=CONFIG):
    """Return a panel with one row per unit (raw features, H, D_obs, S, S2, Z_raw, ...)."""
    u, j, a = raw["user"], raw["job"], raw["action"]
    edu = cfg["edu_map"]

    U = pd.DataFrame({"user_id": u.user_id})
    U["u_edu"] = u.cur_degree_id.map(edu)
    b = _num(u.birthday)
    age = pd.Series(np.where(b > 1900, cfg["ref_year"] - b, b), index=u.index)
    if cfg["mode"] == "final":
        age = age.where(age >= cfg["age_min_valid"])                   # invalid ages (e.g. 0) -> missing
    U["u_age"] = age
    U["u_exp_years"] = cfg["ref_year"] - _num(u.start_work_date)
    if cfg["mode"] == "final":
        U["u_desire_salary_code"] = salary_log_mid(u.desire_jd_salary_id)
    else:
        U["u_desire_salary_code"] = _num(u.desire_jd_salary_id)
    U["u_log_resume_len"] = np.log1p(_len(u.resume_text))
    U["u_n_exp_segments"] = u.experience.fillna("").astype(str).apply(
        lambda s: len([x for x in s.split("|") if x.strip()]))

    J = pd.DataFrame({"jd_no": j.jd_no})
    J["j_min_edu"] = j.min_edu_level.map(edu)
    J["j_log_min_salary"] = np.log1p(_num(j.min_salary).clip(lower=0))
    J["j_log_max_salary"] = np.log1p(_num(j.max_salary).clip(lower=0))
    J["j_years_mid"] = _num(j.min_years).map(cfg["years_mid"])
    rq = _num(j.require_nums)
    J["j_require_nums"] = rq                                           # X keeps the raw coding
    J["zx_require_log"] = np.log1p(rq.where(~rq.isin(cfg["require_sentinels"])).clip(lower=0))
    J["j_is_travel"] = _num(j.is_travel)
    jd_col = "job_description" if "job_description" in j.columns else "job_text"
    J["j_log_jd_len"] = np.log1p(_len(j[jd_col]))

    df = a[["user_id", "jd_no", "browsed", "delivered", "satisfied"]].copy()
    for c in ["browsed", "delivered", "satisfied"]:
        df[c] = _num(df[c]).astype(int)
    unit = cfg.get("unit") or ("row" if cfg["mode"] == "record" else "pair")
    if unit == "pair":
        # collapse repeated records of a pair: ever browsed / ever delivered / ever satisfied
        df["n_records"] = 1
        df = df.groupby(["user_id", "jd_no"], as_index=False, sort=False).agg(
            browsed=("browsed", "max"), delivered=("delivered", "max"),
            satisfied=("satisfied", "max"), n_records=("n_records", "sum"))
    df = df.merge(U, on="user_id", how="left").merge(J, on="jd_no", how="left")
    df["edu_gap"] = df.u_edu - df.j_min_edu
    df["H"] = df.delivered
    df["D_obs"] = np.where(df.H == 1, df.satisfied, np.nan)

    # S: candidate-side ranking score (101 - rank)/100 from rank_job; S2: job-side score from rank_resume
    rj = raw["rank_job"][["user_id", "jd_no", "rank", "satisfied"]].copy()
    rj["S_raw"] = (101 - _num(rj["rank"])) / 100
    rj["rj_label"] = _num(rj.satisfied)
    rj = rj.drop(columns=["rank", "satisfied"]).drop_duplicates(["user_id", "jd_no"])
    df = df.merge(rj, on=["user_id", "jd_no"], how="left")
    rr = raw["rank_resume"][["jd_no", "user_id", "rank"]].copy()
    rr["S2_raw"] = (101 - _num(rr["rank"])) / 100
    rr = rr.drop(columns=["rank"]).drop_duplicates(["user_id", "jd_no"])
    df = df.merge(rr, on=["user_id", "jd_no"], how="left")
    df["ind_s"] = df.S_raw.notna().astype(int)
    df["ind_s2"] = df.S2_raw.notna().astype(int)

    # Z: log(1 + deliveries received by the job), computed on the full log (includes the unit itself); sensitivity only
    df["Z_raw"] = np.log1p(df.groupby("jd_no").H.transform("sum"))
    return df


# --------------------------------------------------------------------------- #
# Job-grouped split and fit-on-train preprocessing
# --------------------------------------------------------------------------- #
def job_split(df, seed, frac_train=CONFIG["frac_train"]):
    """Job-grouped split; returns a boolean array, True = training set.
    Job ids are sorted, permuted with np.random.default_rng(seed), and the first round(frac_train * n)
    jobs form the training set; all units of a job fall on the same side."""
    jobs = np.sort(pd.unique(df.jd_no))
    perm = jobs[np.random.default_rng(seed).permutation(len(jobs))]
    train_jobs = set(perm[:int(round(frac_train * len(jobs)))])
    return df.jd_no.isin(train_jobs).values


class Prep:
    """Fitted on the training split: X mean-imputed and z-scored; S filled on uncovered pairs with the training
    mean of covered values (a label-free constant) and z-scored; Z_exo = first principal component of five job-structure fields."""

    def fit(self, df_tr):
        Xtr = df_tr[X_COLS].astype(float)
        self.x_mean = Xtr.mean()
        Xi = Xtr.fillna(self.x_mean)
        self.x_sd = Xi.std(ddof=0).replace(0, 1)
        self.s_fill = df_tr.S_raw.mean()
        s = df_tr.S_raw.fillna(self.s_fill)
        self.s_mu, self.s_sd = s.mean(), s.std(ddof=0) or 1.0
        z = df_tr.Z_raw
        self.z_mu, self.z_sd = z.mean(), z.std(ddof=0) or 1.0
        Zi = df_tr[ZEXO_INPUT].astype(float)
        self.zx_mean = Zi.mean()
        Zi = Zi.fillna(self.zx_mean)
        self.zx_sd = Zi.std(ddof=0).replace(0, 1)
        self.pca = PCA(n_components=1).fit(((Zi - self.zx_mean) / self.zx_sd).values)
        load = self.pca.components_[0]
        self.zx_sign = 1.0 if load[np.argmax(np.abs(load))] > 0 else -1.0
        zz = self.pca.transform(((Zi - self.zx_mean) / self.zx_sd).values)[:, 0] * self.zx_sign
        self.zexo_mu, self.zexo_sd = zz.mean(), zz.std(ddof=0) or 1.0
        return self

    def transform(self, d):
        X = ((d[X_COLS].astype(float).fillna(self.x_mean) - self.x_mean) / self.x_sd).values
        S = ((d.S_raw.fillna(self.s_fill) - self.s_mu) / self.s_sd).values
        Z = ((d.Z_raw - self.z_mu) / self.z_sd).values
        Zi = (d[ZEXO_INPUT].astype(float).fillna(self.zx_mean) - self.zx_mean) / self.zx_sd
        zexo = (self.pca.transform(Zi.values)[:, 0] * self.zx_sign - self.zexo_mu) / self.zexo_sd
        return dict(X=X, S=S, ind_s=d.ind_s.values.astype(float), Z=Z, Zexo=zexo,
                    H=d.H.values, D=d.D_obs.values)

    def zexo_info(self):
        return dict(share=float(self.pca.explained_variance_ratio_[0]),
                    loadings=dict(zip(ZEXO_INPUT, (self.pca.components_[0] * self.zx_sign).round(3).tolist())))
