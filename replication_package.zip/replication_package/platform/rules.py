# -*- coding: utf-8 -*-
"""
rules.py — fitting and scoring of the decision rules, and evaluation utilities shared by all steps.

Rules (Section 4.2, Table 2):
  raw_S        no fitting; rank by S (unaudited platform signal)
  corr_S_only  logistic D ~ (S, ind_s) on training H=1 pairs (computed, not tabulated)
  corr_XZ      logistic D ~ (X, C)
  corr_logit   logistic: D ~ (X, S, ind_s, C), max_iter = 2000
  corr_gbdt    gradient boosting (200 trees, depth 3, learning rate 0.1, subsample 0.8), inputs as corr_logit
  ipw          propensity e = P(H=1 | X, S, ind_s, C) (logistic, full training split);
               outcome model as corr_logit, fitted on training H=1 pairs with weights 1/clip(e)
The column C depends on the specification:
  spec = "exo"  C = Z_exo (main specification; no competition information)
  spec = "Z"    C = coupled competition column (Appendix A.1)
"""
import numpy as np
from scipy.stats import rankdata
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression

RULES = ["raw_S", "corr_S_only", "corr_XZ", "corr_logit", "corr_gbdt", "ipw"]
MAIN_RULES = ["raw_S", "corr_XZ", "corr_logit", "corr_gbdt", "ipw"]   # rules shown in the tables
GBDT_KW = dict(n_estimators=200, max_depth=3, learning_rate=0.1, subsample=0.8)
CLIP_FIT = (1e-3, 1 - 1e-3)
TIE_SEED = 1206


def design(t, spec):
    """t: output of Prep.transform. Returns the design matrix of each rule."""
    C = t["Zexo"] if spec == "exo" else t["Z"]
    full = np.column_stack([t["X"], t["S"], t["ind_s"], C])
    return dict(S_only=np.column_stack([t["S"], t["ind_s"]]),
                XZ=np.column_stack([t["X"], C]), full=full)


def fit_rules(t_tr, spec, seed):
    d = design(t_tr, spec)
    H = t_tr["H"]
    obs = H == 1
    y = t_tr["D"][obs].astype(int)
    m = {}
    m["corr_S_only"] = LogisticRegression(max_iter=2000).fit(d["S_only"][obs], y)
    m["corr_XZ"] = LogisticRegression(max_iter=2000).fit(d["XZ"][obs], y)
    m["corr_logit"] = LogisticRegression(max_iter=2000).fit(d["full"][obs], y)
    m["corr_gbdt"] = GradientBoostingClassifier(random_state=seed, **GBDT_KW).fit(d["full"][obs], y)
    prop = LogisticRegression(max_iter=2000).fit(d["full"], H)
    e = np.clip(prop.predict_proba(d["full"][obs])[:, 1], *CLIP_FIT)
    m["ipw"] = LogisticRegression(max_iter=2000).fit(d["full"][obs], y, sample_weight=1.0 / e)
    m["_prop"] = prop
    return m


def score_rules(m, t, spec):
    d = design(t, spec)
    s = {"raw_S": t["S"].copy()}
    s["corr_S_only"] = m["corr_S_only"].predict_proba(d["S_only"])[:, 1]
    s["corr_XZ"] = m["corr_XZ"].predict_proba(d["XZ"])[:, 1]
    for r in ["corr_logit", "corr_gbdt", "ipw"]:
        s[r] = m[r].predict_proba(d["full"])[:, 1]
    s["_e"] = m["_prop"].predict_proba(d["full"])[:, 1]
    return s


# --------------------------------------------------------------------------- #
# AUC / DeLong / bootstrap
# --------------------------------------------------------------------------- #
def auc_fast(y, s):
    y = np.asarray(y).astype(bool)
    m, n = y.sum(), (~y).sum()
    if m == 0 or n == 0:
        return np.nan
    r = rankdata(s)
    return (r[y].sum() - m * (m + 1) / 2) / (m * n)


def _delong_parts(y, s):
    y = np.asarray(y).astype(bool)
    pos, neg = s[y], s[~y]
    m, n = len(pos), len(neg)
    tz = rankdata(np.concatenate([pos, neg]))
    tx, ty = rankdata(pos), rankdata(neg)
    auc = (tz[:m].sum() - m * (m + 1) / 2) / (m * n)
    v01 = (tz[:m] - tx) / n
    v10 = 1 - (tz[m:] - ty) / m
    return auc, v01, v10


def delong_test(y, sa, sb):
    """Paired DeLong test: z = (AUC_a - AUC_b)/SE; positive values favour a."""
    from scipy.stats import norm
    a1, p1, n1 = _delong_parts(y, sa)
    a2, p2, n2 = _delong_parts(y, sb)
    var = np.var(p1 - p2, ddof=1) / len(p1) + np.var(n1 - n2, ddof=1) / len(n1)
    z = (a1 - a2) / np.sqrt(var) if var > 0 else np.nan
    return dict(auc_a=a1, auc_b=a2, diff=a1 - a2, z=z, p=2 * (1 - norm.cdf(abs(z))))


def boot_indices(n, B, seed, groups=None):
    """Bootstrap index generator; with groups, whole groups (jobs) are resampled."""
    rng = np.random.default_rng(seed)
    if groups is None:
        for _ in range(B):
            yield rng.integers(0, n, n)
    else:
        codes, uniq = _codes(groups)
        rows = [np.flatnonzero(codes == k) for k in range(len(uniq))]
        G = len(rows)
        for _ in range(B):
            pick = rng.integers(0, G, G)
            yield np.concatenate([rows[k] for k in pick])


def _codes(groups):
    import pandas as pd
    c, u = pd.factorize(np.asarray(groups))
    return c, u


def topk_order(score, seed=TIE_SEED):
    """Order by score (descending); ties broken by a fixed-seed random permutation (deterministic)."""
    jitter = np.random.default_rng(seed).random(len(score))
    return np.lexsort((jitter, -np.asarray(score)))
