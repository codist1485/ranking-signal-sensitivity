# -*- coding: utf-8 -*-
"""
step3_value.py — value of the selected set and value of validation (Section 5.4, Tables 6-7; Appendix A).

Usage (after step 1, with the same --mode):
  python step3_value.py --data <PLATFORM_DIR> --mode final --step1 results/platform_step1 --out results/platform_step3

Estimand: V(pi, B) = mean outcome over the B test units ranked highest by rule pi (full test population);
VoV = V(corr_gbdt) - V(raw_S).
Estimators:
  naive       mean D over the selected units with H = 1
  ipw         self-normalized IPW, w = 1/clip(e, 0.02, 0.98)
  aipw_lin    AIPW with a linear value model (training H = 1)
  aipw_logit  AIPW with a logistic value model (= corr_logit of the exo specification)
  aipw_gbdt   AIPW with a gradient-boosted value model (= corr_gbdt of the exo specification)
  impute      regression imputation mean(H*D + (1-H)*mu_logit)
  manski      model-free bounds (unobserved outcomes set to 0 / 1); width = unobserved share
Propensity e: exo [X, S, ind_s, Z_exo] (main) and exo_noS [X, Z_exo] (Appendix A.2).
Rule scores are read from the step-1 npz files (specifications exo and Z).
Uncertainty: five-split mean/sd; on the primary split, pair and job-clustered bootstrap (1,000 replicates each),
including paired differences. Ties are broken by a fixed permutation (seed 1206) shared by all rules.
Runtime: about 10-20 minutes.
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.metrics import roc_auc_score

import common
from common import load_raw, build_panel, job_split, Prep
from rules import RULES, topk_order, boot_indices

CLIP_EVAL = (0.02, 0.98)
EST = ["naive", "ipw", "aipw_lin", "aipw_logit", "aipw_gbdt", "impute"]
lines = []


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s, flush=True)
    lines.append(s)


def estimates(sel, H, D, e, mu_lin, mu_log, mu_gb):
    """sel: indices of the selected units (may contain repeats in bootstrap replicates)."""
    h = H[sel] == 1
    d = np.nan_to_num(D[sel])
    ec = np.clip(e[sel], *CLIP_EVAL)
    n = len(sel)
    out = {}
    out["naive"] = d[h].mean() if h.any() else np.nan
    w = 1 / ec[h]
    out["ipw"] = (w * d[h]).sum() / w.sum() if h.any() else np.nan
    hh = h.astype(float)
    for k, mu in (("aipw_lin", mu_lin), ("aipw_logit", mu_log), ("aipw_gbdt", mu_gb)):
        m = mu[sel]
        out[k] = np.mean(m + hh / ec * (d - m))
    out["impute"] = (d[h].sum() + mu_log[sel][~h].sum()) / n
    out["manski_lo"] = d[h].sum() / n
    out["manski_hi"] = (d[h].sum() + (~h).sum()) / n
    out["unobs"] = (~h).mean()
    return out


def top_sel(rank, B, idx=None):
    """rank: global rank of each unit under the rule (0 = highest); idx: resampled rows. Returns selected rows."""
    if idx is None:
        return np.argpartition(rank, B - 1)[:B]
    r = rank[idx]
    return idx[np.argpartition(r, B - 1)[:B]]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--mode", choices=["record", "final"], required=True)
    ap.add_argument("--step1", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--Bs", type=int, nargs="+", default=[100, 500, 1000])
    ap.add_argument("--B_main", type=int, default=500)
    ap.add_argument("--nboot", type=int, default=1000)
    ap.add_argument("--seeds", type=int, nargs="+", default=common.CONFIG["seeds_main"])
    args = ap.parse_args()
    t0 = time.time()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    s1 = Path(args.step1)
    common.CONFIG["mode"] = args.mode
    df = build_panel(load_raw(args.data))
    rule_specs = ["exo", "Z"]
    wspecs = ["exo", "exo_noS"]
    log(f"STEP3  mode={args.mode}  n={len(df):,}  rule specs={rule_specs}  weights={wspecs}  "
        f"B={args.Bs} (main {args.B_main})  nboot={args.nboot}")
    primary = args.seeds[0]

    rows, prim_store, r2_rows = [], {}, []
    for seed in args.seeds:
        tr = job_split(df, seed)
        te = ~tr
        prep = Prep().fit(df[tr])
        t_tr, t_te = prep.transform(df[tr]), prep.transform(df[te])
        H, D = t_te["H"], t_te["D"]
        otr = t_tr["H"] == 1
        # propensity models
        E = {}
        for ws in wspecs:
            if ws == "exo_noS":
                Ptr, Pte = np.column_stack([t_tr["X"], t_tr["Zexo"]]), np.column_stack([t_te["X"], t_te["Zexo"]])
            else:
                Ptr = np.column_stack([t_tr["X"], t_tr["S"], t_tr["ind_s"], t_tr["Zexo"]])
                Pte = np.column_stack([t_te["X"], t_te["S"], t_te["ind_s"], t_te["Zexo"]])
            E[ws] = LogisticRegression(max_iter=2000).fit(Ptr, t_tr["H"]).predict_proba(Pte)[:, 1]
        # value models: logistic / GBDT = step-1 corr_logit / corr_gbdt (exo); the linear model is fitted here
        zx = np.load(s1 / f"scores_exo_seed{seed}.npz")
        if not np.array_equal(zx["test_index"], np.flatnonzero(te)):
            raise RuntimeError("step-1 scores do not match this split: use the step-1 directory produced with the same --mode")
        Ftr = np.column_stack([t_tr["X"], t_tr["S"], t_tr["ind_s"], t_tr["Zexo"]])
        Fte = np.column_stack([t_te["X"], t_te["S"], t_te["ind_s"], t_te["Zexo"]])
        mu_lin = LinearRegression().fit(Ftr[otr], t_tr["D"][otr]).predict(Fte)
        mu_log, mu_gb = zx["corr_logit"], zx["corr_gbdt"]
        ho = H == 1
        yv = D[ho]
        for nm, mu in (("linear", mu_lin), ("logistic", mu_log), ("gbdt", mu_gb)):
            r2_rows.append(dict(seed=seed, model=nm, R2=1 - ((yv - mu[ho]) ** 2).sum() / ((yv - yv.mean()) ** 2).sum(),
                                AUC=roc_auc_score(yv, mu[ho])))
        for rs in rule_specs:
            z = np.load(s1 / f"scores_{rs}_seed{seed}.npz")
            ranks = {}
            for r in RULES:
                o = topk_order(z[r])
                rk = np.empty(len(o), int)
                rk[o] = np.arange(len(o))
                ranks[r] = rk
            for ws in wspecs:
                for B in args.Bs:
                    for r in RULES:
                        est = estimates(top_sel(ranks[r], B), H, D, E[ws], mu_lin, mu_log, mu_gb)
                        rows.append(dict(seed=seed, rule_spec=rs, weights=ws, B=B, rule=r, **est))
                if seed == primary:
                    prim_store[(rs, ws)] = dict(ranks=ranks, H=H, D=D, e=E[ws], mu=(mu_lin, mu_log, mu_gb),
                                                jobs=df.jd_no.values[te])
        log(f"  seed {seed}: test units {int(te.sum()):,}  H=1 share {H.mean():.4f}  [{time.time() - t0:.0f}s]")

    res = pd.DataFrame(rows)
    res.to_csv(out / "value_by_seed.csv", index=False)
    r2 = pd.DataFrame(r2_rows)
    log("\n[Value models] R^2 and AUC on the test H=1 units (five splits)")
    log(r2.groupby("model")[["R2", "AUC"]].agg(["mean", "min", "max"]).round(4).to_string())

    cols = EST + ["manski_lo", "manski_hi", "unobs"]
    for rs in rule_specs:
        for ws in wspecs:
            g = res[(res.rule_spec == rs) & (res.weights == ws)]
            log(f"\n================ rule specification {rs} x weights {ws} ================")
            for B in args.Bs:
                gb = g[g.B == B]
                mean = gb.groupby("rule")[cols].mean().reindex(RULES)
                sd = gb.groupby("rule")[["naive", "ipw", "aipw_logit", "aipw_gbdt"]].std().reindex(RULES)
                p = gb[gb.seed == primary].set_index("rule")[["aipw_logit", "aipw_gbdt"]].reindex(RULES)
                tab = mean.copy()
                tab["aipw_logit_sd"] = sd.aipw_logit
                tab["aipw_logit_primary"] = p.aipw_logit
                tab["aipw_gbdt_primary"] = p.aipw_gbdt
                tab.to_csv(out / f"table10_{rs}_{ws}_B{B}.csv")
                log(f"\n[Table 6] B={B}: five-split means (aipw_logit also with sd and primary-split value)")
                log(tab.round(4).to_string())
                vv = gb.pivot_table(index="seed", columns="rule", values=EST + ["manski_lo", "manski_hi"])
                vov = {k: (vv[k]["corr_gbdt"] - vv[k]["raw_S"]).agg(["mean", "std"]).values for k in EST}
                mlo = (vv["manski_lo"]["corr_gbdt"] - vv["manski_hi"]["raw_S"]).mean()
                mhi = (vv["manski_hi"]["corr_gbdt"] - vv["manski_lo"]["raw_S"]).mean()
                log(f"  [B={B}] VoV = V(corr_gbdt) - V(raw_S), five-split mean/sd: " +
                    ", ".join(f"{k} {m:+.4f}±{s:.4f}" for k, (m, s) in vov.items()) +
                    f" | model-free bound [{mlo:+.4f}, {mhi:+.4f}]")

            # ---- bootstrap on the primary split (B_main only)
            P = prim_store[(rs, ws)]
            n = len(P["H"])
            mu_lin, mu_log, mu_gb = P["mu"]
            out_b = {}
            for kind, gen in (("pair", boot_indices(n, args.nboot, 31)),
                              ("cluster", boot_indices(n, args.nboot, 32, groups=P["jobs"]))):
                rec = []
                for idx in gen:
                    row = {}
                    for r in RULES:
                        est = estimates(top_sel(P["ranks"][r], args.B_main, idx), P["H"], P["D"], P["e"],
                                        mu_lin, mu_log, mu_gb)
                        for k in ["naive", "ipw", "aipw_logit", "aipw_gbdt"]:
                            row[(r, k)] = est[k]
                    rec.append(row)
                out_b[kind] = pd.DataFrame(rec)
            point = {r: estimates(top_sel(P["ranks"][r], args.B_main), P["H"], P["D"], P["e"], mu_lin, mu_log, mu_gb)
                     for r in RULES}
            tl = []
            for r in RULES:
                for k in ["naive", "ipw", "aipw_logit", "aipw_gbdt"]:
                    row = dict(rule=r, estimator=k, point=point[r][k])
                    for kind in ("pair", "cluster"):
                        x = out_b[kind][(r, k)].dropna()
                        row[f"{kind}_mean"], row[f"{kind}_sd"] = x.mean(), x.std()
                        row[f"{kind}_lo"], row[f"{kind}_hi"] = np.percentile(x, [2.5, 97.5])
                    tl.append(row)
            tl = pd.DataFrame(tl)
            tl.to_csv(out / f"table14A_{rs}_{ws}.csv", index=False)
            log(f"\n[Levels] primary split, B={args.B_main}: point estimate; pair / job-clustered bootstrap sd and 95% interval")
            log(tl[["rule", "estimator", "point", "pair_sd", "pair_lo", "pair_hi", "cluster_sd", "cluster_lo",
                    "cluster_hi"]].round(4).to_string(index=False))
            pb = []
            for a_, b_ in [("corr_XZ", "raw_S"), ("corr_logit", "raw_S"), ("ipw", "raw_S"), ("corr_gbdt", "raw_S"),
                           ("corr_gbdt", "corr_logit"), ("corr_XZ", "corr_logit")]:
                for k in ["naive", "ipw", "aipw_logit", "aipw_gbdt"]:
                    row = dict(comparison=f"{a_}−{b_}", estimator=k, point=point[a_][k] - point[b_][k])
                    for kind in ("pair", "cluster"):
                        x = (out_b[kind][(a_, k)] - out_b[kind][(b_, k)]).dropna()
                        row[f"{kind}_sd"] = x.std()
                        row[f"{kind}_lo"], row[f"{kind}_hi"] = np.percentile(x, [2.5, 97.5])
                    pb.append(row)
            pb = pd.DataFrame(pb)
            pb.to_csv(out / f"table14B_{rs}_{ws}.csv", index=False)
            log(f"\n[Table 7] paired differences (same replicates)")
            log(pb.round(4).to_string(index=False))

    log(f"\nTotal runtime {time.time() - t0:.0f} s")
    (out / "report.txt").write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    main()
