# -*- coding: utf-8 -*-
"""
step2_selection.py — propensity and weight diagnostics; target-population weighted AUC
(Section 5.3, Table 5; Appendix A.2, Table A1).

Usage (after step 1, with the same --mode):
  python step2_selection.py --data <PLATFORM_DIR> --mode final --step1 results/platform_step1 --out results/platform_step2

Propensity models (logistic on the full training split) that differ only in the competition/coverage columns:
  raw      [X, S, ind_s, Z]        coupled competition column (includes the unit's own delivery)
  loo      [X, S, ind_s, Z_loo]    leave-one-out competition column
  exo      [X, S, ind_s, Z_exo]    main weights
  exo_noS  [X, Z_exo]              without S and ind_s (Appendix A.2)
Table A1: propensity distribution, largest weight, ESS, and the AUC of the ipw rule refitted under each specification.
Table 5: weighted AUC of the step-1 scores (read from the npz files) under the exo and exo_noS weights.
Runtime: about 5-10 minutes.
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

import common
from common import load_raw, build_panel, job_split, Prep
from rules import RULES, CLIP_FIT

CLIP_EVAL = (0.02, 0.98)
PSPECS = ["raw", "loo", "exo", "exo_noS"]

lines = []


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s, flush=True)
    lines.append(s)


def ess_frac(w):
    return float(w.sum() ** 2 / (w ** 2).sum() / len(w))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--mode", choices=["record", "final"], required=True)
    ap.add_argument("--step1", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seeds", type=int, nargs="+", default=common.CONFIG["seeds_main"])
    args = ap.parse_args()
    t0 = time.time()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    s1 = Path(args.step1)
    common.CONFIG["mode"] = args.mode
    raw = load_raw(args.data)
    df = build_panel(raw)
    df["Z_loo_raw"] = np.log1p(df.groupby("jd_no").H.transform("sum") - df.H)
    log(f"STEP2  mode={args.mode}  n={len(df):,}  seeds={args.seeds}")
    primary = args.seeds[0]

    diag_rows, w7_rows = [], []
    for seed in args.seeds:
        tr = job_split(df, seed)
        te = ~tr
        prep = Prep().fit(df[tr])
        t_tr, t_te = prep.transform(df[tr]), prep.transform(df[te])
        zl_tr, zl_te = df.Z_loo_raw.values[tr], df.Z_loo_raw.values[te]
        mu, sd = zl_tr.mean(), zl_tr.std() or 1.0
        comp = {"raw": (t_tr["Z"], t_te["Z"]), "loo": ((zl_tr - mu) / sd, (zl_te - mu) / sd),
                "exo": (t_tr["Zexo"], t_te["Zexo"]), "exo_noS": (t_tr["Zexo"], t_te["Zexo"])}
        Htr, Hte = t_tr["H"], t_te["H"]
        otr, ote = Htr == 1, Hte == 1
        ytr, yte = t_tr["D"][otr].astype(int), t_te["D"][ote].astype(int)
        e_te = {}
        for ps in PSPECS:
            ctr, cte = comp[ps]
            if ps == "exo_noS":
                Ptr, Pte = np.column_stack([t_tr["X"], ctr]), np.column_stack([t_te["X"], cte])
            else:
                Ptr = np.column_stack([t_tr["X"], t_tr["S"], t_tr["ind_s"], ctr])
                Pte = np.column_stack([t_te["X"], t_te["S"], t_te["ind_s"], cte])
            pm = LogisticRegression(max_iter=2000).fit(Ptr, Htr)
            etr = pm.predict_proba(Ptr)[:, 1]
            ete = pm.predict_proba(Pte)[:, 1]
            e_te[ps] = ete
            wtr = 1 / np.clip(etr[otr], *CLIP_FIT)
            wte = 1 / np.clip(ete[ote], *CLIP_EVAL)
            # refit the ipw rule under this specification (outcome features [X, S, ind_s, C])
            Otr = np.column_stack([t_tr["X"], t_tr["S"], t_tr["ind_s"], ctr])
            Ote = np.column_stack([t_te["X"], t_te["S"], t_te["ind_s"], cte])
            om = LogisticRegression(max_iter=2000).fit(Otr[otr], ytr, sample_weight=wtr)
            sc = om.predict_proba(Ote[ote])[:, 1]
            diag_rows.append(dict(
                seed=seed, pspec=ps, nw=int(otr.sum()),
                tr_p5=np.percentile(etr[otr], 5), tr_p95=np.percentile(etr[otr], 95),
                tr_wmax=wtr.max(), tr_ess=ess_frac(wtr),
                te_p5=np.percentile(ete, 5), te_p95=np.percentile(ete, 95), te_min=ete.min(), te_max=ete.max(),
                te_wmax=wte.max(), te_ess=ess_frac(wte), te_share_at_clip=float((ete[ote] <= CLIP_EVAL[0]).mean()),
                ipw_auc=roc_auc_score(yte, sc), ipw_wauc=roc_auc_score(yte, sc, sample_weight=wte)))

        # Table 5: read the step-1 scores of the exo specification
        f = s1 / f"scores_exo_seed{seed}.npz"
        if not f.exists():
            log(f"  [missing {f}; split skipped for Table 5]")
            continue
        z = np.load(f)
        if len(z["test_index"]) != int(te.sum()) or not np.array_equal(z["test_index"], np.flatnonzero(te)):
            raise RuntimeError("step-1 scores do not match this split: use the step-1 directory produced with the same --mode")
        for ps in ["exo", "exo_noS"]:
            w = 1 / np.clip(e_te[ps][ote], *CLIP_EVAL)
            for r in RULES:
                sc = z[r][ote]
                w7_rows.append(dict(seed=seed, weights=ps, rule=r, auc=roc_auc_score(yte, sc),
                                    wauc=roc_auc_score(yte, sc, sample_weight=w)))
        log(f"  seed {seed} done [{time.time() - t0:.0f}s]")

    diag = pd.DataFrame(diag_rows)
    diag.to_csv(out / "table6_by_seed.csv", index=False)
    w7 = pd.DataFrame(w7_rows)
    w7.to_csv(out / "table7_by_seed.csv", index=False)

    log("\n[Table A1] primary split (seed %d)" % primary)
    t6 = diag[diag.seed == primary].set_index("pspec").drop(columns="seed").T
    log(t6.round(4).to_string())
    log("\n[Table A1] range over the five splits (min - max)")
    rng = diag.groupby("pspec")[["tr_wmax", "tr_ess", "te_wmax", "te_ess", "te_min", "ipw_auc", "ipw_wauc"]].agg(["min", "max"])
    log(rng.round(4).to_string())

    for ps in ["exo", "exo_noS"]:
        g = w7[w7.weights == ps].groupby("rule")
        t7 = pd.DataFrame({"auc_mean": g.auc.mean(), "auc_sd": g.auc.std(), "wauc_mean": g.wauc.mean(),
                           "wauc_sd": g.wauc.std()}).reindex(RULES)
        t7["delta"] = t7.wauc_mean - t7.auc_mean
        d = w7[w7.weights == ps].assign(dd=lambda x: x.wauc - x.auc).pivot(index="seed", columns="rule", values="dd")
        t7["delta_same_sign_splits"] = [f"{int((np.sign(d[r]) == np.sign(t7.loc[r, 'delta'])).sum())}/{len(d)}" for r in RULES]
        t7.to_csv(out / f"table7_{ps}.csv")
        log(f"\n[Table 5] weights = {ps}: unweighted vs target-population weighted AUC (five-split mean/sd)")
        log(t7.round(4).to_string())
        pw = w7[(w7.weights == ps) & (w7.seed == primary)].set_index("rule").wauc.reindex(RULES)
        log(f"  primary-split weighted AUC: " + ", ".join(f"{r} {v:.4f}" for r, v in pw.items()))

    log(f"\nTotal runtime {time.time() - t0:.0f} s")
    (out / "report.txt").write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    main()
