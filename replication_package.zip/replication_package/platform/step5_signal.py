# -*- coding: utf-8 -*-
"""
step5_signal.py — endogeneity of the platform signal S (Section 4.1, "Platform signal").
Usage: python step5_signal.py --data <PLATFORM_DIR> --out results/platform_step5
Output: report.txt. Runtime about one minute.
"""
import argparse
from pathlib import Path
import numpy as np
import common
from common import load_raw, build_panel, Prep, X_COLS
ap = argparse.ArgumentParser(); ap.add_argument("--data", required=True); ap.add_argument("--out", default="results_step5")
a = ap.parse_args(); out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
raw = load_raw(a.data); L = []
for mode in ["final", "record"]:
    common.CONFIG["mode"] = mode
    df = build_panel(raw); H = df.H.values; cov = df.ind_s.values == 1
    m = cov & (H == 1)
    X = Prep().fit(df).transform(df)["X"][m]
    s, d = df.S_raw.values[m], df.D_obs.values[m]
    Z = np.column_stack([np.ones(len(X)), X])
    rs = s - Z @ np.linalg.lstsq(Z, s, rcond=None)[0]; rd = d - Z @ np.linalg.lstsq(Z, d, rcond=None)[0]
    L += [f"== mode={mode} (unit={'record' if mode=='record' else 'pair'}) ==",
          f"  units {len(df):,}; S covered {int(cov.sum()):,} ({cov.mean():.4%}); covered & H=1 {int(m.sum()):,}",
          f"  share delivered among covered {H[cov].mean():.4f}",
          f"  P(S observed | H=1) {cov[H==1].mean():.5f};  P(S observed | H=0) {cov[H==0].mean():.6f};  ratio {cov[H==1].mean()/max(cov[H==0].mean(),1e-12):.0f}",
          f"  corr(S, D) on covered H=1: {np.corrcoef(s, d)[0,1]:.4f}",
          f"  partial corr(S, D | X) on covered H=1: {np.corrcoef(rs, rd)[0,1]:.4f}"]
print("\n".join(L)); (out / "report.txt").write_text("\n".join(L), encoding="utf-8")
