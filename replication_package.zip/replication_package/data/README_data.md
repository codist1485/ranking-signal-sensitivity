# Data

No data are included in this package.

## 1. Platform data (Sections 4–5)

Source: Alibaba Cloud Tianchi, *2019 Alibaba Job–Resume Intelligent Matching Competition*,
https://tianchi.aliyun.com/competition/entrance/231728, used under the original Tianchi competition
data-use agreement. The data have not been publicly downloadable since 11 September 2023 and may not be
redistributed. Researchers who hold the competition files can reproduce all results.

The scripts expect five CSV files (UTF-8, one header row) in a single directory:

| File | Records | Key columns used |
|---|---|---|
| `user.csv` | 4,465 | `user_id, desire_jd_salary_id, cur_degree_id, birthday, start_work_date, experience, resume_text` |
| `job.csv` | 38,162 | `jd_no, require_nums, max_salary, min_salary, is_travel, min_years, min_edu_level, job_description` |
| `action.csv` | 217,281 | `user_id, jd_no, browsed, delivered, satisfied` |
| `rank_job.csv` | 30,000 | `user_id, rank, jd_no, satisfied` (candidate-side ranking; 300 candidates × 100 jobs) |
| `rank_resume.csv` | 30,000 | `jd_no, rank, user_id, satisfied` (job-side ranking; 300 jobs × 100 candidates) |

`rank_job.csv` and `rank_resume.csv` are the competition's ranking files flattened to one row per
(query, candidate) with the rank position. Additional columns are ignored. `platform/common.py` documents
every cleaning and encoding step (Section 4.1 of the paper).

## 2. Coat (Section 6.2)

Download from https://www.cs.cornell.edu/~schnabts/mnar/ (Schnabel et al., ICML 2016) and unzip.
Expected layout:

```
coat/
├── train.ascii  test.ascii  propensities.ascii
└── user_item_features/
    ├── user_features.ascii  item_features.ascii
    └── user_features_map.txt  item_features_map.txt
```

## 3. KuaiRand-Pure (Section 6.3)

Download KuaiRand-Pure from https://kuairand.com/ (Gao et al., CIKM 2022). Pass the directory that
contains the CSV files:

```
log_standard_4_08_to_4_21_pure.csv   log_standard_4_22_to_5_08_pure.csv
log_random_4_22_to_5_08_pure.csv     user_features_pure.csv
video_features_basic_pure.csv
```
