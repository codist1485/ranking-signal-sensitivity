# Replication package

**Paper:** *Coverage, Selection, and the Value of Validation: A Sensitivity Framework for Evaluating Ranking Signals under Selective Labels* (under review; anonymized).

This package reproduces every number, table and figure in the paper from the original data files. It contains no data. The platform data cannot be redistributed; Coat and KuaiRand-Pure are public and must be downloaded from their providers (see `data/README_data.md`).

## 1. Directory structure

```
.
├── README.md                     this file
├── requirements.txt              Python dependencies
├── run_all.sh / run_all.bat      run the complete pipeline (Linux/macOS / Windows)
├── data/
│   └── README_data.md            how to obtain the data and where to put it
├── platform/                     job-matching platform (Sections 4–5, Appendix A)
│   ├── common.py                 loading, cleaning, pair-level collapsing, variables, job-grouped split
│   ├── rules.py                  decision rules, AUC, DeLong test, bootstrap utilities
│   ├── step1_main.py             ranking on the visible subset, decomposition, subgroups, coverage ceiling
│   ├── step2_selection.py        propensity/weight diagnostics, target-population weighted AUC
│   ├── step3_value.py            value of the selected set, VoV, Manski bounds, clustered bootstrap
│   ├── step4_gamma.py            Γ-sensitivity analysis, breakdown value Γ*, covariate benchmark
│   └── step5_signal.py           endogeneity of the platform signal S
├── benchmarks/
│   ├── coat/coat_experiment.py           Coat (user self-selection; Section 6.2)
│   └── kuairand/kuairand_experiment.py   KuaiRand-Pure (recommender exposure; Section 6.3)
├── synthetic/
│   └── synthetic_experiment.py   fully specified synthetic control (Section 6.1)
├── tools/
│   ├── make_toy_data.py          schema-compatible toy data for smoke tests
│   └── make_figure3.py           Figure 3 from the outputs of step 4, Coat and KuaiRand
└── reference_results/            the reports produced by the authors' run (for comparison)
```

## 2. Requirements

Python ≥ 3.10 and the packages in `requirements.txt`. The reference results were produced with Python 3.14 on
Windows (numpy 2.4.4, pandas 3.0.2, scipy 1.17.1, scikit-learn 1.8.0, matplotlib 3.11.2); the pipeline was also
tested with Python 3.12 on Linux.

```
pip install -r requirements.txt
```

Memory: about 2 GB for the platform and Coat; 4–6 GB for KuaiRand. A complete run takes about 1–2 hours on a desktop PC (most of it in bootstrap replicates and in KuaiRand).

## 3. Quick start: smoke test without the original data

```
python tools/make_toy_data.py --out toy_data
bash run_all.sh toy_data/platform toy_data/coat toy_data/kuairand toy_results --quick
```

This runs every script end to end in a few minutes on toy data. The numbers are meaningless; the test only checks that the pipeline runs.

## 4. Full reproduction

Place the data as described in `data/README_data.md`, then run

```
bash run_all.sh <PLATFORM_DIR> <COAT_DIR> <KUAIRAND_DATA_DIR> results
```

or, on Windows, `run_all.bat` with absolute paths. Each step writes a `report.txt` and CSV files to its own sub-directory of `results/`. The steps can also be run individually; the platform steps must be run from `platform/`, and steps 2–4 read the scores saved by step 1:

```
cd platform
python step1_main.py      --data <PLATFORM_DIR> --mode final --out ../results/platform_step1
python step2_selection.py --data <PLATFORM_DIR> --mode final --step1 ../results/platform_step1 --out ../results/platform_step2
python step3_value.py     --data <PLATFORM_DIR> --mode final --step1 ../results/platform_step1 --out ../results/platform_step3
python step4_gamma.py     --data <PLATFORM_DIR> --step1 ../results/platform_step1 --out ../results/platform_step4
python step5_signal.py    --data <PLATFORM_DIR> --out ../results/platform_step5
```

`--mode final` is the analysis reported in the paper (candidate–job pairs); `--mode record` runs steps 1–3 on the raw interaction records instead of pairs and reproduces Appendix A.3 (use separate output directories).

## 5. Where each result comes from

| Paper item | Script | Output file(s) |
|---|---|---|
| Section 4.1 (data counts, unit of analysis) | `platform/step1_main.py`, `platform/step5_signal.py` | `platform_step1/report.txt`, `platform_step5/report.txt` |
| Section 4.1 (platform signal S, endogeneity) | `platform/step5_signal.py` | `platform_step5/report.txt` |
| Table 3 (ranking, top-k) | `platform/step1_main.py` | `platform_step1/table3_exo.csv`, `topk_exo.csv` |
| Coverage ceiling, coverage-adjusted AUC (Sec. 5.1) | `platform/step1_main.py` | `platform_step1/coverage.json` |
| Section 5.2 (decomposition), Table 4 (subgroups) | `platform/step1_main.py` | `decomposition_exo.csv`, `subgroup_exo.csv` |
| Section 5.3, Table A1 (propensity diagnostics) | `platform/step2_selection.py` | `platform_step2/table6_by_seed.csv` |
| Table 5 (weighted AUC) | `platform/step2_selection.py` | `platform_step2/table7_exo.csv` |
| Table 6 (value of the top-500 set) | `platform/step3_value.py` | `platform_step3/table10_exo_exo_B500.csv` |
| Table 7 (paired clustered differences) | `platform/step3_value.py` | `platform_step3/table14B_exo_exo.csv` |
| Value-model diagnostics, B = 100 / 1000 (Sec. 5.4) | `platform/step3_value.py` | `platform_step3/report.txt`, `table10_exo_exo_B*.csv` |
| Table 8, Figure 1 (Γ*), covariate benchmark | `platform/step4_gamma.py` | `platform_step4/gamma_star_by_seed.csv`, `report.txt`, `gamma_plot_platform.png`, `covariate_benchmark.csv` |
| Table 9, Figure 2 (synthetic control) | `synthetic/synthetic_experiment.py` | `synthetic/table9_summary.csv`, `synthetic_results.csv` |
| Table 10 (Coat) | `benchmarks/coat/coat_experiment.py` | `coat_t4/value_by_rule.csv`, `auc_by_rule.csv`, `vov.csv`, `report.txt` |
| Table 11 (KuaiRand) | `benchmarks/kuairand/kuairand_experiment.py` | `kuairand_click/value.csv`, `report.txt` |
| Figure 3 (Γ anchors) | `tools/make_figure3.py` (reads steps 4, Coat, KuaiRand) | `figure3_gamma_anchors.png` |
| Appendix A.1 (with competition column) | steps 1–3 (specification `Z`, run automatically) | `*_Z*.csv` in steps 1–3 |
| Appendix A.2 (propensity specifications) | steps 2–3 (weights `exo_noS`, run automatically) | `table7_exo_noS.csv`, `table10_exo_exo_noS_B*.csv` |
| Appendix A.3 (record-level analysis) | steps 1–3 with `--mode record` | as for steps 1–3 |
| Appendix A.4 (benchmark checks) | Coat with `--threshold 3`; KuaiRand with `--outcome long_view` | `coat_t3/`, `kuairand_longview/` |

## 6. Determinism

All randomness is seeded. Job-grouped splits: seeds 42 (primary), 123, 2024, 7, 999 (job identifiers sorted, permuted with `numpy.random.default_rng(seed)`, first 80% for training). Tie-breaking of scores: a fixed permutation with seed 1206 shared by all rules. Bootstrap, cross-fitting and model seeds are fixed in each script. Small numerical differences (in the fourth decimal) can arise across library versions.

## 7. Licence

Code: MIT licence (see `LICENSE`, to be added on de-anonymization). The data are subject to the licences of their providers.
