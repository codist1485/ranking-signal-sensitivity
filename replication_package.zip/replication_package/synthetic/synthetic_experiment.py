# -*- coding: utf-8 -*-
"""
synthetic_experiment.py — fully specified synthetic control for the Gamma framework (Section 6.1, Table 9, Figure 2).
Usage: python synthetic_experiment.py --out results/synthetic [--seeds 20]
DGP (per replicate, seed s):
  X ~ N(0, I_5), n = 100,000
  D ~ Bernoulli(sigmoid(eta)),  eta = -0.3 + X b_f + t * X0 * X1,  b_f = (0.8, -0.6, 0.5, 0.4, -0.3)
  H ~ Bernoulli(sigmoid(a + X b_h + kappa * D)),  b_h = (0.7, 0.5, -0.4, 0, 0.3),
      a solved so that P(H=1) = 0.35.  The odds of D=1 given X differ between H=1 and H=0
      by a factor in [1, exp(kappa)], so Gamma_true = exp(kappa) bounds the sensitivity parameter.
  kappa in {0, 0.5, 1, 1.5};  t in {0 (additive), 1.5 (interaction)};  20 seeds.
Random 50/50 fitting/evaluation split. Rules fitted on fitting-half H=1:
  pre   : platform-like weak signal, score = X0 + N(0, 1.5^2)
  logit : logistic on X;  ipw : logistic on X weighted by 1/clip(e_hat) ;  gbdt : HistGradientBoosting on X
Value of the top-5% evaluation set; estimators naive / IPW (Hajek) / AIPW (mu = gbdt) / impute (mu = gbdt).
"""
import numpy as np, pandas as pd, sys, time
from scipy.special import expit
from scipy.optimize import brentq
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score
BF=np.array([.8,-.6,.5,.4,-.3]); BH=np.array([.7,.5,-.4,0,.3])
GRID=np.unique(np.concatenate([np.exp(np.linspace(0,np.log(50),500)),[1e9]]))
def band(sel,H,D,mu):
    h=H[sel]==1; obs=D[sel][h].sum(); p=np.clip(mu[sel][~h],1e-9,1-1e-9)[None,:]; g=GRID[:,None]
    n=len(sel); return (obs+(p/(p+g*(1-p))).sum(1))/n,(obs+(g*p/(g*p+1-p)).sum(1))/n
def one(seed,kappa,t,n=100000,q=0.05):
    r=np.random.default_rng(seed*100+int(kappa*10)+int(t*10)*1000)
    X=r.standard_normal((n,5)); eta=-0.3+X@BF+t*X[:,0]*X[:,1]; D=(r.random(n)<expit(eta)).astype(int)
    lin=X@BH; a=brentq(lambda a: expit(a+lin+kappa*D).mean()-0.35,-10,10)
    H=(r.random(n)<expit(a+lin+kappa*D)).astype(int)
    fit=r.random(n)<0.5; ev=~fit
    of=fit&(H==1)
    pm=LogisticRegression(max_iter=1000).fit(X[fit],H[fit]); e=pm.predict_proba(X)[:,1]
    lg=LogisticRegression(max_iter=1000).fit(X[of],D[of])
    ip=LogisticRegression(max_iter=1000).fit(X[of],D[of],sample_weight=1/np.clip(e[of],1e-3,1))
    gb=HistGradientBoostingClassifier(max_iter=200,random_state=seed).fit(X[of],D[of])
    S={"pre":X[:,0]+r.normal(0,1.5,n),"logit":lg.predict_proba(X)[:,1],"ipw":ip.predict_proba(X)[:,1],"gbdt":gb.predict_proba(X)[:,1]}
    idx=np.flatnonzero(ev); He,De=H[idx],D[idx]; mu=S["gbdt"][idx]; ec=np.clip(e[idx],.02,.98)
    out=dict(seed=seed,kappa=kappa,t=t,H_rate=H.mean())
    out["auc_logit"]=roc_auc_score(De,S["logit"][idx]); out["auc_ipw"]=roc_auc_score(De,S["ipw"][idx])
    out["auc_gbdt"]=roc_auc_score(De,S["gbdt"][idx]); out["auc_pre"]=roc_auc_score(De,S["pre"][idx])
    vis=He==1; out["auc_visible_logit"]=roc_auc_score(De[vis],S["logit"][idx][vis])
    k=int(q*len(idx)); bands={}
    for nm in ["pre","logit","gbdt","ipw"]:
        sel=np.argpartition(-S[nm][idx],k-1)[:k]; h=He[sel]==1; d=De[sel]
        w=1/ec[sel][h]
        out[f"{nm}_truth"]=d.mean(); out[f"{nm}_naive"]=d[h].mean(); out[f"{nm}_ipw"]=(w*d[h]).sum()/w.sum()
        out[f"{nm}_aipw"]=np.mean(mu[sel]+h/ec[sel]*(d*h-mu[sel])); out[f"{nm}_impute"]=(d[h].sum()+mu[sel][~h].sum())/k
        out[f"{nm}_unobs"]=(~h).mean()
        lo,hi=band(sel,He,De,mu); bands[nm]=(lo,hi)
        c=GRID[(lo<=out[f"{nm}_truth"])&(hi>=out[f"{nm}_truth"])]; out[f"{nm}_gamma_cover"]=c[0] if len(c) else np.inf
        gi=np.searchsorted(GRID,np.exp(kappa)); out[f"{nm}_covered_at_true"]=int(lo[gi]<=out[f"{nm}_truth"]<=hi[gi])
    vlo=bands["gbdt"][0]-bands["pre"][1]; hit=np.flatnonzero(vlo<=0)
    out["vov_truth"]=out["gbdt_truth"]-out["pre_truth"]
    for est in ["naive","ipw","aipw","impute"]: out[f"vov_{est}"]=out[f"gbdt_{est}"]-out[f"pre_{est}"]
    out["gamma_star"]=GRID[hit[0]] if (len(hit) and vlo[0]>0) else np.nan
    return out
def summarize(d):
    g=d.groupby(["t","kappa"])
    tab=pd.DataFrame({"exp_kappa":np.exp(g.kappa.first()),
        "dAUC_ipw_minus_logit":(d.auc_ipw-d.auc_logit).groupby([d.t,d.kappa]).mean(),
        "naive_bias":(d.gbdt_naive-d.gbdt_truth).groupby([d.t,d.kappa]).mean(),
        "aipw_bias":(d.gbdt_aipw-d.gbdt_truth).groupby([d.t,d.kappa]).mean(),
        "emp_gamma_post_median":g.gbdt_gamma_cover.median(),
        "emp_gamma_pre_median":g.pre_gamma_cover.median(),
        "vov_truth":g.vov_truth.mean(),"vov_aipw":g.vov_aipw.mean(),
        "gamma_star_median":g.gamma_star.median()})
    return tab
if __name__=="__main__":
    import argparse, pathlib
    ap=argparse.ArgumentParser(); ap.add_argument("--out",default="results_synthetic"); ap.add_argument("--seeds",type=int,default=20)
    args=ap.parse_args(); out=pathlib.Path(args.out); out.mkdir(parents=True,exist_ok=True)
    t0=time.time(); rows=[]
    for t in [0.0,1.5]:
        for kappa in [0.0,0.5,1.0,1.5]:
            for s in range(args.seeds): rows.append(one(s,kappa,t))
            print(f"t={t} kappa={kappa} done [{time.time()-t0:.0f}s]",flush=True)
    d=pd.DataFrame(rows); d.to_csv(out/"synthetic_results.csv",index=False)
    tab=summarize(d); tab.round(4).to_csv(out/"table9_summary.csv")
    (out/"report.txt").write_text(tab.round(4).to_string(),encoding="utf-8"); print(tab.round(4).to_string())
