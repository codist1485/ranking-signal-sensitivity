@echo off
REM Usage: run_all.bat <PLATFORM_DATA_DIR> <COAT_DIR> <KUAIRAND_DATA_DIR> <OUT_DIR>
REM Relative paths are resolved against the current directory. Full run: about 1-2 hours on a desktop PC.
setlocal
set PLAT=%~1
set COAT=%~2
set KR=%~3
set OUT=%~4
if "%OUT%"=="" set OUT=%~dp0results
REM convert all paths to absolute paths (the script changes directory between steps)
for %%I in ("%PLAT%") do set "PLAT=%%~fI"
for %%I in ("%COAT%") do set "COAT=%%~fI"
for %%I in ("%KR%") do set "KR=%%~fI"
for %%I in ("%OUT%") do set "OUT=%%~fI"
if not exist "%OUT%" mkdir "%OUT%"
set ROOT=%~dp0
cd /d "%ROOT%platform"
python step1_main.py      --data "%PLAT%" --mode final --out "%OUT%\platform_step1" || goto :err
python step2_selection.py --data "%PLAT%" --mode final --step1 "%OUT%\platform_step1" --out "%OUT%\platform_step2" || goto :err
python step3_value.py     --data "%PLAT%" --mode final --step1 "%OUT%\platform_step1" --out "%OUT%\platform_step3" || goto :err
python step4_gamma.py     --data "%PLAT%" --step1 "%OUT%\platform_step1" --out "%OUT%\platform_step4" || goto :err
python step5_signal.py    --data "%PLAT%" --out "%OUT%\platform_step5" || goto :err
cd /d "%ROOT%benchmarks\coat"
python coat_experiment.py --data "%COAT%" --out "%OUT%\coat_t4" || goto :err
python coat_experiment.py --data "%COAT%" --threshold 3 --out "%OUT%\coat_t3" || goto :err
cd /d "%ROOT%benchmarks\kuairand"
python kuairand_experiment.py --data "%KR%" --out "%OUT%\kuairand_click" || goto :err
python kuairand_experiment.py --data "%KR%" --outcome long_view --out "%OUT%\kuairand_longview" || goto :err
cd /d "%ROOT%synthetic"
python synthetic_experiment.py --out "%OUT%\synthetic" || goto :err
cd /d "%ROOT%"
python tools\make_figure3.py --results "%OUT%" || goto :err
echo All done. Reports: %OUT%\*\report.txt
goto :eof
:err
echo A step failed; see the message above.
exit /b 1
